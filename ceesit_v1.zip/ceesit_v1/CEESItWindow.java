package ceesit_v1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;














public class CEESItWindow
  extends JFrame
{
  private JPanel basePanel;
  private JPanel filesPanel;
  private JPanel numericInputPanel;
  private JPanel DNAMassPanel;
  private JPanel NumberContibutorsPanel;
  private JPanel NumberSamplesPanel;
  private JPanel thetaPanel;
  private JPanel buttonsPanel;
  private JPanel panelForFilesPanelBorder;
  private JPanel progressBarPanel;
  private JLabel calibrationFileLabel;
  private JLabel sampleFileLabel;
  private JLabel frequencyFileLabel;
  private JLabel poiGenotypeFileLabel;
  private JLabel outputFileLabel;
  private JLabel DNAMassLabel;
  private JLabel NumberContributorsLabel;
  private JLabel NumberSamplesLabel;
  private JLabel thetaLabel;
  private JTextField DNAMassSelection;
  private JTextField NumberContributorsSelection;
  private JTextField NumberSamplesSelection;
  private JTextField thetaSelection;
  private final Dimension fileSelectionValueLabelDimension = new Dimension(200, 20);
  
  private JLabel sampleFileSelectionValueLabel;
  
  private JLabel frequencyFileSelectionValueLabel;
  
  private JLabel poiGenotypeFileSelectionValueLabel;
  
  private JLabel calibrationFileSelectionValueLabel;
  
  private JLabel outputFileSelectionValueLabel;
  private ArrayList<JButton> buttons;
  private JProgressBar progressBar;
  private JButton calibrationFileSelectionButton;
  private JButton sampleFileSelectionButton;
  private JButton frequencyFileSelectionButton;
  private JButton poiGenotypeFileSelectionButton;
  private JButton createOutputFileButton;
  private JButton startButton;
  private JButton stopButton;
  
  public CEESItWindow()
  {
    buttons = new ArrayList();
    setupPanels();
    setupFrame();
  }
  
  public CEESItWindow(ActionListener listener) {
    setupPanels();
    setupFrame();
    calibrationFileSelectionButton.addActionListener(listener);
  }
  
  public JButton getSampleFileSelectionButton() {
    return sampleFileSelectionButton;
  }
  
  private void setupPanels()
  {
    basePanel = new JPanel();
    basePanel.setOpaque(true);
    basePanel.setLayout(new BoxLayout(basePanel, 3));
    basePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
    


    calibrationFileLabel = new JLabel("Calibration file: ");
    sampleFileLabel = new JLabel("Sample file:  ");
    outputFileLabel = new JLabel("Output file:");
    frequencyFileLabel = new JLabel("Frequency file:");
    poiGenotypeFileLabel = new JLabel("POI genotype file: ");
    DNAMassLabel = new JLabel("Sample DNA input:");
    NumberContributorsLabel = new JLabel("Number of contributors (1-3):");
    NumberSamplesLabel = new JLabel("Number of random simulated genotypes:");
    thetaLabel = new JLabel("Population substructure correction factor (theta):");
    


    calibrationFileSelectionValueLabel = new JLabel(" ", 0);
    calibrationFileSelectionValueLabel.setName("calibrationFileSelection");
    calibrationFileSelectionValueLabel.setPreferredSize(fileSelectionValueLabelDimension);
    calibrationFileSelectionValueLabel.setBorder(new EtchedBorder());
    calibrationFileSelectionValueLabel.setOpaque(true);
    calibrationFileSelectionValueLabel.setBackground(Color.WHITE);
    
    sampleFileSelectionValueLabel = new JLabel("", 0);
    sampleFileSelectionValueLabel.setName("sampleFileSelection");
    sampleFileSelectionValueLabel.setPreferredSize(fileSelectionValueLabelDimension);
    sampleFileSelectionValueLabel.setBorder(new EtchedBorder());
    sampleFileSelectionValueLabel.setOpaque(true);
    sampleFileSelectionValueLabel.setBackground(Color.WHITE);
    
    frequencyFileSelectionValueLabel = new JLabel("", 0);
    frequencyFileSelectionValueLabel.setName("frequencyFileSelection");
    frequencyFileSelectionValueLabel.setPreferredSize(fileSelectionValueLabelDimension);
    frequencyFileSelectionValueLabel.setBorder(new EtchedBorder());
    frequencyFileSelectionValueLabel.setOpaque(true);
    frequencyFileSelectionValueLabel.setBackground(Color.WHITE);
    
    poiGenotypeFileSelectionValueLabel = new JLabel("", 0);
    poiGenotypeFileSelectionValueLabel.setName("poiGenotypeFileSelection");
    poiGenotypeFileSelectionValueLabel.setPreferredSize(fileSelectionValueLabelDimension);
    poiGenotypeFileSelectionValueLabel.setBorder(new EtchedBorder());
    poiGenotypeFileSelectionValueLabel.setOpaque(true);
    poiGenotypeFileSelectionValueLabel.setBackground(Color.WHITE);
    
    outputFileSelectionValueLabel = new JLabel("", 0);
    outputFileSelectionValueLabel.setName("outputFileSelection");
    outputFileSelectionValueLabel.setPreferredSize(fileSelectionValueLabelDimension);
    outputFileSelectionValueLabel.setBorder(new EtchedBorder());
    outputFileSelectionValueLabel.setOpaque(true);
    outputFileSelectionValueLabel.setBackground(Color.WHITE);
    

    DNAMassSelection = new JTextField("", 5);
    DNAMassSelection.setName("DNAMassSelection");
    
    NumberContributorsSelection = new JTextField("", 5);
    NumberContributorsSelection.setName("NumberContributorsSelection");
    
    NumberSamplesSelection = new JTextField("1000000000", 8);
    NumberSamplesSelection.setName("NumberSamplesSelection");
    
    thetaSelection = new JTextField("", 5);
    thetaSelection.setName("thetaSelection");
    





    calibrationFileSelectionButton = new JButton("Browse");
    calibrationFileSelectionButton.setActionCommand("calibration");
    buttons.add(calibrationFileSelectionButton);
    
    sampleFileSelectionButton = new JButton("Browse");
    sampleFileSelectionButton.setActionCommand("sample");
    buttons.add(sampleFileSelectionButton);
    
    frequencyFileSelectionButton = new JButton("Browse");
    frequencyFileSelectionButton.setActionCommand("frequency");
    buttons.add(frequencyFileSelectionButton);
    
    poiGenotypeFileSelectionButton = new JButton("Browse");
    poiGenotypeFileSelectionButton.setActionCommand("poiGenotype");
    buttons.add(poiGenotypeFileSelectionButton);
    
    createOutputFileButton = new JButton("Browse");
    createOutputFileButton.setActionCommand("output");
    buttons.add(createOutputFileButton);
    

    startButton = new JButton("START");
    startButton.setActionCommand("start");
    buttons.add(startButton);
    
    stopButton = new JButton("STOP");
    stopButton.setActionCommand("stop");
    buttons.add(stopButton);
    

    DNAMassPanel = new JPanel();
    DNAMassPanel.setLayout(new FlowLayout(0));
    DNAMassPanel.add(DNAMassLabel);
    DNAMassPanel.add(DNAMassSelection);
    
    NumberContibutorsPanel = new JPanel();
    NumberContibutorsPanel.setLayout(new FlowLayout(0));
    NumberContibutorsPanel.add(NumberContributorsLabel);
    NumberContibutorsPanel.add(NumberContributorsSelection);
    
    NumberSamplesPanel = new JPanel();
    NumberSamplesPanel.setLayout(new FlowLayout(0));
    NumberSamplesPanel.add(NumberSamplesLabel);
    NumberSamplesPanel.add(NumberSamplesSelection);
    
    thetaPanel = new JPanel();
    thetaPanel.setLayout(new FlowLayout(0));
    thetaPanel.add(thetaLabel);
    thetaPanel.add(thetaSelection);
    





    numericInputPanel = new JPanel();
    numericInputPanel.setLayout(new BoxLayout(numericInputPanel, 3));
    numericInputPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 5, 10), BorderFactory.createEtchedBorder()));
    numericInputPanel.add(DNAMassPanel);
    numericInputPanel.add(NumberContibutorsPanel);
    numericInputPanel.add(NumberSamplesPanel);
    numericInputPanel.add(thetaPanel);
    



    filesPanel = new JPanel(new GridBagLayout());
    filesPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    GridBagConstraints c = new GridBagConstraints();
    
    gridx = 0;
    gridy = 0;
    insets = new Insets(4, 4, 4, 4);
    fill = 0;
    
    filesPanel.add(calibrationFileLabel, c);
    
    gridy = 1;
    filesPanel.add(frequencyFileLabel, c);
    
    gridy = 2;
    filesPanel.add(sampleFileLabel, c);
    
    gridy = 3;
    filesPanel.add(poiGenotypeFileLabel, c);
    
    gridy = 4;
    filesPanel.add(outputFileLabel, c);
    
    gridx = 1;
    gridy = 0;
    fill = 1;
    
    filesPanel.add(calibrationFileSelectionValueLabel, c);
    
    gridy = 1;
    filesPanel.add(frequencyFileSelectionValueLabel, c);
    
    gridy = 2;
    filesPanel.add(sampleFileSelectionValueLabel, c);
    
    gridy = 3;
    filesPanel.add(poiGenotypeFileSelectionValueLabel, c);
    
    gridy = 4;
    filesPanel.add(outputFileSelectionValueLabel, c);
    
    gridx = 2;
    gridy = 0;
    fill = 0;
    filesPanel.add(calibrationFileSelectionButton, c);
    
    gridy = 1;
    filesPanel.add(frequencyFileSelectionButton, c);
    
    gridy = 2;
    filesPanel.add(sampleFileSelectionButton, c);
    
    gridy = 3;
    filesPanel.add(poiGenotypeFileSelectionButton, c);
    
    gridy = 4;
    filesPanel.add(createOutputFileButton, c);
    
    panelForFilesPanelBorder = new JPanel();
    panelForFilesPanelBorder.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(5, 10, 5, 10), BorderFactory.createEtchedBorder()));
    panelForFilesPanelBorder.add(filesPanel);
    

    progressBar = new JProgressBar();
    progressBar.setStringPainted(true);
    progressBar.setString("");
    progressBarPanel = new JPanel();
    progressBarPanel.add(progressBar);
    progressBarPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(5, 10, 5, 10), BorderFactory.createEtchedBorder()));
    

    buttonsPanel = new JPanel();
    buttonsPanel.setLayout(new FlowLayout(1));
    buttonsPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(5, 10, 10, 10), BorderFactory.createEtchedBorder()));
    buttonsPanel.add(startButton);
    buttonsPanel.add(stopButton);
    basePanel.add(panelForFilesPanelBorder);
    basePanel.add(numericInputPanel);
    basePanel.add(progressBarPanel);
    basePanel.add(buttonsPanel);
  }
  
  private void setupFrame() {
    setContentPane(basePanel);
    setDefaultCloseOperation(3);
    setResizable(false);
    setTitle("CEESIt");
    pack();
  }
  
  public void addActionListenerToAllButtons(ActionListener listener) {
    for (JButton b : buttons) {
      b.addActionListener(listener);
    }
  }
  


  public void setCalibrationFileSelectionText(String selection)
  {
    calibrationFileSelectionValueLabel.setText(selection);
  }
  
  public String getCalibrationFileSelectionText() {
    return calibrationFileSelectionValueLabel.getText();
  }
  
  public void setFrequencyFileSelectionText(String selection) {
    frequencyFileSelectionValueLabel.setText(selection);
  }
  
  public String getFrequencyFileSelectionText() {
    return frequencyFileSelectionValueLabel.getText();
  }
  
  public void setSampleFileSelectionText(String selection) {
    sampleFileSelectionValueLabel.setText(selection);
  }
  
  public String getSampleFileSelectionText() {
    return sampleFileSelectionValueLabel.getText();
  }
  
  public void setpoiGenotypeFileSelectionText(String selection) {
    poiGenotypeFileSelectionValueLabel.setText(selection);
  }
  
  public String getpoiGenotypeFileSelectionText() {
    return poiGenotypeFileSelectionValueLabel.getText();
  }
  
  public JProgressBar getProgressBar() {
    return progressBar;
  }
  
  public void setOutputFileSelectionText(String selection) {
    outputFileSelectionValueLabel.setText(selection);
  }
  
  public String getOutputFileSelectionText() {
    return outputFileSelectionValueLabel.getText();
  }
  
  public String getDNAMassSelectionText() {
    return DNAMassSelection.getText();
  }
  
  public String getNoContibutorsText() {
    return NumberContributorsSelection.getText();
  }
  
  public String getNumberSamplesText() {
    return NumberSamplesSelection.getText();
  }
  
  public String getThetaText() {
    return thetaSelection.getText();
  }
  



  public void setStartButtonEnabled(Boolean b)
  {
    startButton.setEnabled(b.booleanValue());
  }
}
