package ceesit_v1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.JOptionPane;
import org.apache.commons.math.MathException;
import org.apache.commons.math.optimization.fitting.CurveFitter;
import org.apache.commons.math.optimization.fitting.ParametricRealFunction;
import org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer;
import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

public class CEESItAlgorithm
{
  private static int num_processors;
  private static double genotype_tolerance;
  private static int[] interference_samples;
  private static double min_height;
  
  public CEESItAlgorithm() {}
  
  public void runCEESIt(File sampleFile, File frequencyFile, File poiFile, File outputFile, File calibrationFile, int NumberContributors, int PValueSamples, double dnaMass, double Theta, javax.swing.JProgressBar progBar) throws InterruptedException, ExecutionException, org.apache.commons.math.FunctionEvaluationException, IOException, org.apache.commons.math.optimization.OptimizationException, MathException
  {
    double initial_time = System.currentTimeMillis();
    
    inexactPValue = false;
    
    interference_samples = new int[] { 10000, 50000 };
    min_height = 1.0D;
    genotype_tolerance = 0.1D;
    
    offset = -300.0D;
    largestAllele = 0;
    
    twoPi = 6.283185307179586D;
    

    String male = "M";String female = "F";
    Sexes = new String[] { "M", "F" };
    String[] male_genotype = { "X", "Y" };
    String[] female_genotype = { "X", "X" };
    Sexes_Genotype = new HashMap();
    Sexes_Genotype.put(male, male_genotype);
    Sexes_Genotype.put(female, female_genotype);
    
    LevenbergMarquardtOptimizer lmo = new LevenbergMarquardtOptimizer();
    lmo.setMaxIterations(10000000);
    
    num_processors = Runtime.getRuntime().availableProcessors();
    
    Loci_no_true = new HashSet();
    Loci_no_noise = new HashSet();
    Loci_RStutter = new HashSet();
    Loci_FStutter = new HashSet();
    Loci_not_in_freq_table = new HashSet();
    Loci_not_in_calib_samples = new HashSet();
    


    Freq_File = frequencyFile.getAbsolutePath();
    calibrationPath = calibrationFile.getAbsolutePath();
    poiGenFile = poiFile.getAbsolutePath();
    Sample_File_Name = sampleFile.getAbsolutePath();
    Output_File_Name = outputFile.getAbsolutePath();
    DNA_Mass = dnaMass;
    noc = NumberContributors;
    poiSamples = PValueSamples;
    
    theta = Theta;
    


    mixRatios = new ArrayList();
    if (noc == 2) {
      double[] mr1 = { 0.1D, 0.9D };
      double[] mr2 = { 0.2D, 0.8D };
      double[] mr3 = { 0.3D, 0.7D };
      double[] mr4 = { 0.4D, 0.6D };
      double[] mr5 = { 0.5D, 0.5D };
      double[] mr6 = { 0.6D, 0.4D };
      double[] mr7 = { 0.7D, 0.3D };
      double[] mr8 = { 0.8D, 0.2D };
      double[] mr9 = { 0.9D, 0.1D };
      mixRatios.add(mr1);
      mixRatios.add(mr2);
      mixRatios.add(mr3);
      mixRatios.add(mr4);
      mixRatios.add(mr5);
      mixRatios.add(mr6);
      mixRatios.add(mr7);
      mixRatios.add(mr8);
      mixRatios.add(mr9);
    }
    else if (noc == 3) {
      double[] mr1 = { 0.45D, 0.38D, 0.17D };
      double[] mr2 = { 0.38D, 0.17D, 0.45D };
      mr3 = new double[] { 0.17D, 0.45D, 0.38D };
      double[] mr4 = { 0.62D, 0.27D, 0.11D };
      double[] mr5 = { 0.11D, 0.62D, 0.27D };
      double[] mr6 = { 0.27D, 0.11D, 0.62D };
      double[] mr7 = { 0.81D, 0.09D, 0.1D };
      double[] mr8 = { 0.1D, 0.81D, 0.09D };
      double[] mr9 = { 0.09D, 0.1D, 0.81D };
      double[] mr10 = { 0.56D, 0.11D, 0.33D };
      double[] mr11 = { 0.33D, 0.56D, 0.11D };
      double[] mr12 = { 0.11D, 0.33D, 0.56D };
      mixRatios.add(mr1);
      mixRatios.add(mr2);
      mixRatios.add(mr3);
      mixRatios.add(mr4);
      mixRatios.add(mr5);
      mixRatios.add(mr6);
      mixRatios.add(mr7);
      mixRatios.add(mr8);
      mixRatios.add(mr9);
      mixRatios.add(mr10);
      mixRatios.add(mr11);
      mixRatios.add(mr12);
    }
    else if (noc == 1) {
      double[] mr = { 1.0D };
      mixRatios.add(mr);
    }
    
    mrProb = Math.log10(1.0D / mixRatios.size());
    
    FreqTable FreqTableObject = new FreqTable(Freq_File);
    Freq_Table = FreqTableObject.getFreqTable();
    freqAlleles = FreqTableObject.getFreqAlleles();
    AllPossibleAlleles = FreqTableObject.getAllPossAlleles();
    ArrayList<String> Freq_Loci = FreqTableObject.getFreqLociList();
    
    freqOK = FreqTableObject.allOk();
    if (!freqOK) {
      return;
    }
    
    Freq_Intervals = Intervals(Freq_Table, Freq_Loci);
    AlleleFreqDist_Final_Values = new HashMap();
    for (double[] mr3 = Freq_Loci.iterator(); mr3.hasNext();) { locus = (String)mr3.next();
      Set<Integer> keys_set = ((LinkedHashMap)Freq_Intervals.get(locus)).keySet();
      List<Integer> keys_array = new ArrayList();
      keys_array.addAll(keys_set);
      Integer last_key = (Integer)keys_array.get(keys_array.size() - 1);
      AlleleFreqDist_Final_Values.put(locus, last_key);
    }
    String locus;
    largestAllele += 20;
    
    parseSampleFile pSFObject = new parseSampleFile(Sample_File_Name);
    Loci_Peaks = pSFObject.getLociPeaks();
    Sample_Loci = pSFObject.getSampleLoci();
    Loci_HeightsDist = pSFObject.getLociHeightsDist();
    AMEL_Peaks = pSFObject.getAMELPeaks();
    
    Heights_Intervals = Intervals(Loci_HeightsDist, Sample_Loci);
    
    HeightsDist_Final_Values = new HashMap();
    for (String locus : Sample_Loci) {
      if (!locus.contentEquals("AMEL")) {
        Set<Integer> keys_set = ((LinkedHashMap)Heights_Intervals.get(locus)).keySet();
        List<Integer> keys_array = new ArrayList();
        keys_array.addAll(keys_set);
        Integer last_key = (Integer)keys_array.get(keys_array.size() - 1);
        HeightsDist_Final_Values.put(locus, last_key);
      }
    }
    
    sampleOK = pSFObject.allOk();
    if (!sampleOK) {
      return;
    }
    
    POI_genotype_create poigc = new POI_genotype_create(poiGenFile);
    True_POI_gen = poigc.getPOIgen();
    True_POI_AMELgen = poigc.getPOIAMELgen();
    poiFileOK = poigc.allOK();
    if (!poiFileOK) {
      return;
    }
    
    CalibDataCollection cdcobject = new CalibDataCollection(calibrationPath, Freq_Table);
    HashMap<Double, HashMap<String, Double>> Calib_DO = cdcobject.getDOCalibData();
    HashMap<Double, HashMap<String, Double>> Calib_NoiseDO = cdcobject.getNoiseDOCalibData();
    HashMap<Double, HashMap<String, Double>> Calib_rstutDO = cdcobject.getrstutDOCalibData();
    HashMap<Double, HashMap<String, Double>> Calib_fstutDO = cdcobject.getfstutDOCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_True = cdcobject.getTrueCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_Noise = cdcobject.getNoiseCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_rstut = cdcobject.getrstutterCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_fstut = cdcobject.getfstutterCalibData();
    HashSet<String> Calib_Loci = cdcobject.getLoci();
    HashSet<Double> Calib_Masses = cdcobject.getMasses();
    calibOK = cdcobject.allOk();
    if (!calibOK) {
      return;
    }
    
    AllOK = everythingOK();
    if (!AllOK) {
      return;
    }
    


    ArrayList<Double> calib_masses = new ArrayList(Calib_Masses);
    Collections.sort(calib_masses);
    
    HashSet<String> Loci_cannot_work = new HashSet();
    
    True_Mean_Slope = new HashMap();
    True_Stddev_Slope = new HashMap();
    Noise_Mean_Slope = new HashMap();
    Noise_Stddev_Slope = new HashMap();
    R_Stutter_Mean = new HashMap();
    R_Stutter_Stddev = new HashMap();
    F_Stutter_Mean = new HashMap();
    F_Stutter_Stddev = new HashMap();
    Locus_DO = new HashMap();
    R_Stut_DO = new HashMap();
    F_Stut_DO = new HashMap();
    
    for (String locus : Calib_Loci)
    {

      ArrayList<Double> total_True_Masses = new ArrayList();
      ArrayList<Double> total_noise_Masses = new ArrayList();
      ArrayList<Double> total_rstut_Masses = new ArrayList();
      ArrayList<Double> total_fstut_Masses = new ArrayList();
      ArrayList<Double> total_DO_Masses = new ArrayList();
      ArrayList<Double> total_rstutDO_Masses = new ArrayList();
      ArrayList<Double> total_fstutDO_Masses = new ArrayList();
      ArrayList<Double> total_noiseDO_Values = new ArrayList();
      

      CurveFitter truemean_fitter = new CurveFitter(lmo);
      CurveFitter truestddev_fitter = new CurveFitter(lmo);
      CurveFitter noisemean_fitter = new CurveFitter(lmo);
      CurveFitter noisestddev_fitter = new CurveFitter(lmo);
      CurveFitter rstutmean_fitter = new CurveFitter(lmo);
      CurveFitter rstutstddev_fitter = new CurveFitter(lmo);
      CurveFitter fstutmean_fitter = new CurveFitter(lmo);
      CurveFitter fstutstddev_fitter = new CurveFitter(lmo);
      CurveFitter do_fitter = new CurveFitter(lmo);
      CurveFitter rstutdo_fitter = new CurveFitter(lmo);
      CurveFitter fstutdo_fitter = new CurveFitter(lmo);
      

      double[] truemean_init = { 3000.0D, 10.0D };
      double[] truestddev_init = { 1000.0D, 5.0D };
      double[] noisemean_init = { 5.0D, 3.0D };
      double[] noisestddev_init = { 3.0D, 1.0D };
      double[] rstutmean_init = { 0.0D, -50.0D, 0.0D };
      double[] rstutstddev_init = { 0.0D, -50.0D, 0.0D };
      double[] fstutmean_init = { 0.0D, -50.0D, 0.0D };
      double[] fstutstddev_init = { 0.0D, -50.0D, 0.0D };
      double[] do_init = { 0.0D, -100.0D };
      double[] rstutdo_init = { 0.0D, 20.0D };
      double[] fstutdo_init = { 0.0D, -1.0D };
      
      for (Iterator localIterator2 = calib_masses.iterator(); localIterator2.hasNext();) { double mass = ((Double)localIterator2.next()).doubleValue();
        Double true_mean = (Double)((ArrayList)((HashMap)Calib_True.get(Double.valueOf(mass))).get(locus)).get(0);
        Double true_stddev = (Double)((ArrayList)((HashMap)Calib_True.get(Double.valueOf(mass))).get(locus)).get(1);
        if ((!true_mean.isNaN()) && (!true_stddev.isNaN()) && (true_stddev.doubleValue() != 0.0D)) {
          total_True_Masses.add(Double.valueOf(mass));
          truemean_fitter.addObservedPoint(mass, true_mean.doubleValue());
          truestddev_fitter.addObservedPoint(mass, true_stddev.doubleValue());
        }
        
        Double noise_meanval = (Double)((ArrayList)((HashMap)Calib_Noise.get(Double.valueOf(mass))).get(locus)).get(0);
        Double noise_stddevval = (Double)((ArrayList)((HashMap)Calib_Noise.get(Double.valueOf(mass))).get(locus)).get(1);
        if ((!noise_meanval.isNaN()) && (!noise_stddevval.isNaN()) && (noise_stddevval.doubleValue() != 0.0D)) {
          total_noise_Masses.add(Double.valueOf(mass));
          noisemean_fitter.addObservedPoint(mass, noise_meanval.doubleValue());
          noisestddev_fitter.addObservedPoint(mass, noise_stddevval.doubleValue());
        }
        
        Double DOval = (Double)((HashMap)Calib_DO.get(Double.valueOf(mass))).get(locus);
        if ((!DOval.isInfinite()) && (!DOval.isNaN())) {
          total_DO_Masses.add(Double.valueOf(mass));
          do_fitter.addObservedPoint(mass, DOval.doubleValue());
        }
        
        total_noiseDO_Values.add(((HashMap)Calib_NoiseDO.get(Double.valueOf(mass))).get(locus));
        
        if (!locus.contentEquals("AMEL")) {
          Double rstutDOval = (Double)((HashMap)Calib_rstutDO.get(Double.valueOf(mass))).get(locus);
          if ((!rstutDOval.isInfinite()) && (!rstutDOval.isNaN())) {
            total_rstutDO_Masses.add(Double.valueOf(mass));
            rstutdo_fitter.addObservedPoint(mass, rstutDOval.doubleValue());
          }
          
          Double rstut_meanval = (Double)((ArrayList)((HashMap)Calib_rstut.get(Double.valueOf(mass))).get(locus)).get(0);
          Double rstut_stddevval = (Double)((ArrayList)((HashMap)Calib_rstut.get(Double.valueOf(mass))).get(locus)).get(1);
          if ((!rstut_meanval.isNaN()) && (!rstut_stddevval.isNaN()) && (rstut_stddevval.doubleValue() != 0.0D)) {
            rstutmean_fitter.addObservedPoint(mass, rstut_meanval.doubleValue());
            rstutstddev_fitter.addObservedPoint(mass, rstut_stddevval.doubleValue());
            total_rstut_Masses.add(Double.valueOf(mass));
          }
          
          Double fstutDOval = (Double)((HashMap)Calib_fstutDO.get(Double.valueOf(mass))).get(locus);
          if ((!fstutDOval.isNaN()) && (!fstutDOval.isInfinite())) {
            total_fstutDO_Masses.add(Double.valueOf(mass));
            fstutdo_fitter.addObservedPoint(mass, fstutDOval.doubleValue());
          }
          
          Double fstut_meanval = (Double)((ArrayList)((HashMap)Calib_fstut.get(Double.valueOf(mass))).get(locus)).get(0);
          fstut_stddevval = (Double)((ArrayList)((HashMap)Calib_fstut.get(Double.valueOf(mass))).get(locus)).get(1);
          if ((!fstut_meanval.isNaN()) && (!fstut_stddevval.isNaN()) && (fstut_stddevval.doubleValue() != 0.0D)) {
            fstutmean_fitter.addObservedPoint(mass, fstut_meanval.doubleValue());
            fstutstddev_fitter.addObservedPoint(mass, fstut_stddevval.doubleValue());
            total_fstut_Masses.add(Double.valueOf(mass));
          }
        }
      }
      
      Double fstut_stddevval;
      double[] truemean_best = new double[2];
      double[] truestddev_best = new double[2];
      double[] noisemean_best = new double[2];
      double[] noisestddev_best = new double[2];
      double[] rstutmean_best = new double[3];
      double[] rstutstddev_best = new double[3];
      double[] fstutmean_best = new double[3];
      double[] fstutstddev_best = new double[3];
      double[] do_best = { 0.0D, 0.0D };
      double[] rstutdo_best = { 0.0D, 0.0D };
      double[] fstutdo_best = { 0.0D, 0.0D };
      

      if (total_True_Masses.size() > 1) {
        truemean_best = truemean_fitter.fit(new LinFunction(null), truemean_init);
        truestddev_best = truestddev_fitter.fit(new LinFunction(null), truestddev_init);
      }
      else {
        Loci_cannot_work.add(locus);
        Loci_no_true.add(locus);
      }
      
      if (total_noise_Masses.size() > 1) {
        noisemean_best = noisemean_fitter.fit(new LinFunction(null), noisemean_init);
        noisestddev_best = noisestddev_fitter.fit(new LinFunction(null), noisestddev_init);
      }
      else {
        Loci_cannot_work.add(locus);
        Loci_no_noise.add(locus);
      }
      
      if (total_DO_Masses.size() > 1) {
        do_best = do_fitter.fit(new ExpFunction(null), do_init);
      }
      
      if (!locus.contentEquals("AMEL")) {
        if (total_rstut_Masses.size() > 2) {
          rstutmean_best = rstutmean_fitter.fit(new TwoExpFunction(null), rstutmean_init);
          rstutstddev_best = rstutstddev_fitter.fit(new TwoExpFunction(null), rstutstddev_init);
          Loci_RStutter.add(locus);
        }
        
        if (total_fstut_Masses.size() > 2) {
          fstutmean_best = fstutmean_fitter.fit(new TwoExpFunction(null), fstutmean_init);
          fstutstddev_best = fstutstddev_fitter.fit(new TwoExpFunction(null), fstutstddev_init);
          Loci_FStutter.add(locus);
        }
        
        if (total_rstutDO_Masses.size() > 1) {
          rstutdo_best = rstutdo_fitter.fit(new ExpFunction(null), rstutdo_init);
        }
        
        if (total_fstutDO_Masses.size() > 1) {
          fstutdo_best = fstutdo_fitter.fit(new ExpFunction(null), fstutdo_init);
        }
      }
      
      if (!Loci_cannot_work.contains(locus)) {
        if (truemean_best[0] < 0.0D) {
          truemean_best[0] = 0.0D;
        }
        if (truemean_best[1] < 0.0D) {
          truemean_best[1] = 0.0D;
        }
        if (truestddev_best[0] < 0.0D) {
          truestddev_best[0] = 0.0D;
        }
        if (truestddev_best[1] < 0.5D) {
          truestddev_best[1] = 0.5D;
        }
        if (noisemean_best[0] < 0.0D) {
          noisemean_best[0] = 0.0D;
        }
        if (noisemean_best[1] < 0.0D) {
          noisemean_best[1] = 0.0D;
        }
        if (noisestddev_best[0] < 0.0D) {
          noisestddev_best[0] = 0.0D;
        }
        if (noisestddev_best[1] < 0.5D) {
          noisestddev_best[1] = 0.5D;
        }
        True_Mean_Slope.put(locus, truemean_best);
        True_Stddev_Slope.put(locus, truestddev_best);
        Noise_Mean_Slope.put(locus, noisemean_best);
        Noise_Stddev_Slope.put(locus, noisestddev_best);
        Locus_DO.put(locus, do_best);
        
        double sum = 0.0D;
        for (fstut_stddevval = total_noiseDO_Values.iterator(); fstut_stddevval.hasNext();) { double val = ((Double)fstut_stddevval.next()).doubleValue();
          sum += val;
        }
        double probNoiseDO = sum / total_noiseDO_Values.size();
        Noise_DO.put(locus, Double.valueOf(probNoiseDO));
      }
      
      if (!locus.contentEquals("AMEL")) {
        if (Loci_RStutter.contains(locus)) {
          if (rstutmean_best[2] < 0.005D) {
            rstutmean_best[2] = 0.005D;
          }
          if (rstutstddev_best[2] < 0.005D) {
            rstutstddev_best[2] = 0.005D;
          }
          R_Stutter_Mean.put(locus, rstutmean_best);
          R_Stutter_Stddev.put(locus, rstutstddev_best);
          R_Stut_DO.put(locus, rstutdo_best);
        }
        
        if (Loci_FStutter.contains(locus)) {
          if (fstutmean_best[2] < 0.005D) {
            fstutmean_best[2] = 0.005D;
          }
          if (fstutstddev_best[2] < 0.005D) {
            fstutstddev_best[2] = 0.005D;
          }
          F_Stutter_Mean.put(locus, fstutmean_best);
          F_Stutter_Stddev.put(locus, fstutstddev_best);
          F_Stut_DO.put(locus, fstutdo_best);
        }
      }
    }
    


    Working_Loci = new ArrayList();
    for (String locus : Sample_Loci) {
      if (Calib_Loci.contains(locus)) {
        if (!Loci_cannot_work.contains(locus)) {
          if (!locus.contentEquals("AMEL")) {
            if (Freq_Loci.contains(locus))
            {

              Locus l = new Locus(locus, (HashMap)Loci_Peaks.get(locus), (HashSet)AllPossibleAlleles.get(locus), (LinkedHashMap)Heights_Intervals.get(locus), (LinkedHashMap)Freq_Table.get(locus), (LinkedHashMap)Loci_HeightsDist.get(locus), (double[])True_Mean_Slope.get(locus), (double[])True_Stddev_Slope.get(locus), (double[])Locus_DO.get(locus), (double[])Noise_Mean_Slope.get(locus), (double[])Noise_Stddev_Slope.get(locus), ((Double)Noise_DO.get(locus)).doubleValue(), (double[])R_Stutter_Mean.get(locus), (double[])R_Stutter_Stddev.get(locus), (double[])R_Stut_DO.get(locus), (double[])F_Stutter_Mean.get(locus), (double[])F_Stutter_Stddev.get(locus), (double[])F_Stut_DO.get(locus));
              Working_Loci.add(l);
            }
            else {
              Loci_not_in_freq_table.add(locus);
            }
            
          }
          else
          {
            Locus l = new Locus(locus, (HashMap)Loci_Peaks.get(locus), (HashSet)AllPossibleAlleles.get(locus), (LinkedHashMap)Heights_Intervals.get(locus), (LinkedHashMap)Freq_Table.get(locus), (LinkedHashMap)Loci_HeightsDist.get(locus), (double[])True_Mean_Slope.get(locus), (double[])True_Stddev_Slope.get(locus), (double[])Locus_DO.get(locus), (double[])Noise_Mean_Slope.get(locus), (double[])Noise_Stddev_Slope.get(locus), ((Double)Noise_DO.get(locus)).doubleValue(), (double[])R_Stutter_Mean.get(locus), (double[])R_Stutter_Stddev.get(locus), (double[])R_Stut_DO.get(locus), (double[])F_Stutter_Mean.get(locus), (double[])F_Stutter_Stddev.get(locus), (double[])F_Stut_DO.get(locus));
            Working_Loci.add(l);
          }
        }
      }
      else {
        Loci_not_in_calib_samples.add(locus);
      }
    }
    
    workGenotypes = new HashMap();
    AMELworkGenotypes = new HashMap();
    AMELgenoProbs = new HashMap();
    freqGenotypes = new LinkedHashMap();
    genoProbs = new HashMap();
    for (Locus locus : Working_Loci) {
      AMELgenoProbs.put(locus, new HashMap());
      AMELworkGenotypes.put(locus, new ArrayList());
      genoProbs.put(locus, new HashMap());
      workGenotypes.put(locus, new ArrayList());
      freqGenotypes.put(locus, new LinkedHashMap());
    }
    
    randPOIProbs = new HashMap();
    
    treeCreation();
    
    for (Locus locus : Working_Loci) { int i;
      int j; ArrayList<STR_Allele> Geno; if (!locus.getName().contentEquals("AMEL")) {
        for (i = 0; i < ((ArrayList)freqAlleles.get(name)).size(); i++) {
          for (j = i; j < ((ArrayList)freqAlleles.get(name)).size(); j++) {
            Geno = new ArrayList();
            STR_Allele allele1 = (STR_Allele)((ArrayList)freqAlleles.get(name)).get(i);
            STR_Allele allele2 = (STR_Allele)((ArrayList)freqAlleles.get(name)).get(j);
            
            Geno.add(allele1);
            Geno.add(allele2);
            
            double freq1 = ((Double)((LinkedHashMap)Freq_Table.get(name)).get(allele1)).doubleValue();
            double freq2 = ((Double)((LinkedHashMap)Freq_Table.get(name)).get(allele2)).doubleValue();
            
            ArrayList<Double> probs = new ArrayList();
            for (int k = 0; k < mixRatios.size(); k++) {
              probs.add(((ArrayList)((HashMap)genoProbs.get(locus)).get(Geno)).get(k));
            }
            
            if (((Double)Collections.max(probs)).doubleValue() != Double.NEGATIVE_INFINITY) {
              ((ArrayList)workGenotypes.get(locus)).add(Geno);
              double freq;
              double freq; if (allele1 != allele2) {
                freq = 2.0D * freq1 * freq2;
              }
              else {
                freq = freq1 * freq1 + freq1 * (1.0D - freq1) * theta;
              }
              
              ((LinkedHashMap)freqGenotypes.get(locus)).put(Geno, Double.valueOf(freq));
            }
          }
        }
      }
      else {
        i = Sexes;j = i.length; for (Geno = 0; Geno < j; Geno++) { String sex = i[Geno];
          ArrayList<String> Geno = new ArrayList(Arrays.asList((Object[])Sexes_Genotype.get(sex)));
          
          ArrayList<Double> probs = new ArrayList();
          for (int k = 0; k < mixRatios.size(); k++) {
            probs.add(((ArrayList)((HashMap)AMELgenoProbs.get(locus)).get(Geno)).get(k));
          }
          
          if (((Double)Collections.max(probs)).doubleValue() != Double.NEGATIVE_INFINITY) {
            ((ArrayList)AMELworkGenotypes.get(locus)).add(Geno);
          }
        }
      }
    }
    

    genoFreqIntervals = GenotypeIntervals(freqGenotypes, Working_Loci);
    
    genoFreqDistFinalValues = new HashMap();
    for (Locus locus : Working_Loci) {
      if (!locus.getName().contentEquals("AMEL")) {
        Set<Integer> keys_set = ((LinkedHashMap)genoFreqIntervals.get(locus)).keySet();
        List<Integer> keys_array = new ArrayList();
        keys_array.addAll(keys_set);
        last_key = (Integer)keys_array.get(keys_array.size() - 1);
        genoFreqDistFinalValues.put(locus, last_key);
      }
    }
    Integer last_key;
    probWorkGenotypes = 1.0D;
    for (Locus locus : Working_Loci) {
      double probLocus = 0.0D;
      if (!locus.getName().contentEquals("AMEL")) {
        for (ArrayList<STR_Allele> geno : (ArrayList)workGenotypes.get(locus)) {
          double freq = ((Double)((LinkedHashMap)freqGenotypes.get(locus)).get(geno)).doubleValue();
          probLocus += freq;
        }
        
      } else {
        for (ArrayList<String> geno : (ArrayList)AMELworkGenotypes.get(locus)) {
          double freq = 0.5D;
          probLocus += freq;
        }
      }
      probWorkGenotypes *= probLocus;
    }
    



    double[] mixRatioProbs = new double[mixRatios.size()];
    for (int k = 0; k < mixRatios.size(); k++) {
      double mixRatioProb = 0.0D;
      for (Locus locus : Working_Loci) {
        if (!name.contentEquals("AMEL")) {
          ArrayList<STR_Allele> poiGeno = (ArrayList)True_POI_gen.get(name);
          double logLocusProb = ((Double)((ArrayList)((HashMap)genoProbs.get(locus)).get(poiGeno)).get(k)).doubleValue();
          mixRatioProb += logLocusProb;
        }
        else {
          ArrayList<String> poiGeno = (ArrayList)True_POI_AMELgen.get(name);
          double logLocusProb = ((Double)((ArrayList)((HashMap)AMELgenoProbs.get(locus)).get(poiGeno)).get(k)).doubleValue();
          mixRatioProb += logLocusProb;
        }
      }
      mixRatioProbs[k] = mixRatioProb;
    }
    Arrays.sort(mixRatioProbs);
    double max = mixRatioProbs[(mixRatioProbs.length - 1)];
    double sum = 0.0D;
    for (int i = 0; i < mixRatioProbs.length; i++) {
      double logValue = mixRatioProbs[i];
      double newLogValue = max - logValue;
      sum += Math.pow(10.0D, -newLogValue);
    }
    if (max == Double.NEGATIVE_INFINITY) {
      truePoiProb = Double.valueOf(Double.NEGATIVE_INFINITY);
    }
    else {
      truePoiProb = Double.valueOf(max + Math.log10(sum) + mrProb);
    }
    if (truePoiProb.doubleValue() != Double.NEGATIVE_INFINITY)
    {
      ArrayList<double[]> results = randomPathTreeTraversal();
      
      double[] pValues = (double[])results.get(0);
      
      numGensGreaterPOI = pValues[0];
      
      if (numGensGreaterPOI == 0.0D) {
        inexactPValue = true;
        numGensGreaterPOI = 1.0D;
      }
      
      truePValue = probWorkGenotypes * numGensGreaterPOI / poiSamples;
      
      double LRDenFirstTermSum = ((double[])results.get(1))[0];
      
      LRDen = Math.log10(probWorkGenotypes) + offset + Math.log10(LRDenFirstTermSum) - Math.log10(poiSamples);
      trueLR = Double.valueOf(truePoiProb.doubleValue() - LRDen);
    }
    



    double final_time = System.currentTimeMillis();
    double time = (final_time - initial_time) / 60000.0D;
    time_taken = Math.round(time * 100.0D) / 100.0D;
    
    printCEESItResults();
  }
  




  private static void treeCreation()
    throws InterruptedException, ExecutionException, MathException
  {
    double[] mixRatio;
    



    for (int k = 0; k < mixRatios.size(); k++)
    {
      mixRatio = (double[])mixRatios.get(k);
      
      for (Locus locus : Working_Loci) { int i;
        int j;
        STR_Allele allele1; if (!locus.getName().contentEquals("AMEL"))
        {
          for (i = 0; i < ((ArrayList)freqAlleles.get(name)).size(); i++)
          {
            for (j = i; j < ((ArrayList)freqAlleles.get(name)).size(); j++)
            {
              ArrayList<STR_Allele> Alleles = new ArrayList();
              
              allele1 = (STR_Allele)((ArrayList)freqAlleles.get(name)).get(i);
              STR_Allele allele2 = (STR_Allele)((ArrayList)freqAlleles.get(name)).get(j);
              
              ArrayList<STR_Allele> Geno = new ArrayList();
              Geno.add(allele1);
              Geno.add(allele2);
              
              Alleles.add(allele1);
              if (!Alleles.contains(allele2)) {
                Alleles.add(allele2);
              }
              
              Double logProb = null;
              
              if (noc > 1) {
                logProb = Double.valueOf(calcPOIProb(locus, Geno, mixRatio));

              }
              else if (noc == 1)
              {
                double[] masses = new double[largestAllele + 1];
                
                for (STR_Allele allele : Geno) {
                  masses[allele.getValue()] += DNA_Mass;
                }
                
                logProb = Double.valueOf(Math.log10(calcLocusProbMostCombos(locus, Alleles, masses)));
              }
              

              if (k == 0) {
                ((HashMap)genoProbs.get(locus)).put(Geno, new ArrayList());
              }
              
              ((ArrayList)((HashMap)genoProbs.get(locus)).get(Geno)).add(logProb);
            }
          }
        }
        else
        {
          i = Sexes;j = i.length; for (allele1 = 0; allele1 < j; allele1++) { String sex = i[allele1];
            ArrayList<String> Geno = new ArrayList();
            String allele1 = ((String[])Sexes_Genotype.get(sex))[0];
            String allele2 = ((String[])Sexes_Genotype.get(sex))[1];
            Geno.add(allele1);
            Geno.add(allele2);
            
            ArrayList<String> AMEL_Alleles = new ArrayList();
            AMEL_Alleles.add(allele1);
            if (!AMEL_Alleles.contains(allele2)) {
              AMEL_Alleles.add(allele2);
            }
            
            Double logProb = null;
            
            if (noc > 1) {
              logProb = Double.valueOf(calcPOIProbAMEL(locus, Geno, mixRatio));

            }
            else if (noc == 1)
            {
              HashMap<String, Double> masses = new HashMap();
              
              for (String allele : Geno) {
                if (masses.containsKey(allele)) {
                  masses.put(allele, Double.valueOf(((Double)masses.get(allele)).doubleValue() + DNA_Mass));
                }
                else {
                  masses.put(allele, Double.valueOf(DNA_Mass));
                }
              }
              
              logProb = Double.valueOf(Math.log10(calcLocusProbMostCombosAMEL(locus, AMEL_Alleles, masses)));
            }
            

            if (k == 0) {
              ((HashMap)AMELgenoProbs.get(locus)).put(Geno, new ArrayList());
            }
            ((ArrayList)((HashMap)AMELgenoProbs.get(locus)).get(Geno)).add(logProb);
          }
        }
      }
    }
  }
  



  private static ArrayList<double[]> randomPathTreeTraversal()
    throws InterruptedException, ExecutionException
  {
    double t_p_value = 0.0D;
    
    double LRDen_FirstTerm_Sum = 0.0D;
    
    double numOfIterations = poiSamples / num_processors;
    
    ExecutorService executor = Executors.newFixedThreadPool(num_processors);
    
    Set<threadRandomPathJob> Callables = new HashSet();
    
    for (int j = 1; j <= num_processors; j++) {
      Callables.add(new threadRandomPathJob(numOfIterations));
    }
    
    List<Future<Callable_threadRandomPathJob_object>> Futures = executor.invokeAll(Callables);
    
    for (Future<Callable_threadRandomPathJob_object> future : Futures) {
      ctrpjobject = (Callable_threadRandomPathJob_object)future.get();
      
      t_p_value += ctrpjobject.getTruePValue();
      
      LRDen_FirstTerm_Sum += ctrpjobject.getLRDenFirstTermSum();
      
      for (localIterator2 = ctrpjobject.getRandPOIProbs().keySet().iterator(); localIterator2.hasNext();) { double prob = ((Double)localIterator2.next()).doubleValue();
        if (!randPOIProbs.containsKey(Double.valueOf(prob))) {
          randPOIProbs.put(Double.valueOf(prob), ctrpjobject.getRandPOIProbs().get(Double.valueOf(prob)));
        }
        else {
          randPOIProbs.put(Double.valueOf(prob), Integer.valueOf(((Integer)randPOIProbs.get(Double.valueOf(prob))).intValue() + ((Integer)ctrpjobject.getRandPOIProbs().get(Double.valueOf(prob))).intValue()));
        }
      }
    }
    Callable_threadRandomPathJob_object ctrpjobject;
    Iterator localIterator2;
    executor.shutdown();
    
    Object results = new ArrayList();
    
    double[] p_values = { t_p_value };
    
    double[] lrden = { LRDen_FirstTerm_Sum };
    
    ((ArrayList)results).add(p_values);
    ((ArrayList)results).add(lrden);
    return results;
  }
  
  private static class Callable_threadRandomPathJob_object
  {
    private final double tpval;
    private final double LRDenFirstTermSum;
    private final HashMap<Double, Integer> rand_poi_probs;
    
    Callable_threadRandomPathJob_object(double tpval, double lrdensum, HashMap<Double, Integer> randpoiprobs)
    {
      this.tpval = tpval;
      LRDenFirstTermSum = lrdensum;
      rand_poi_probs = randpoiprobs;
    }
    
    public double getTruePValue() { return tpval; }
    
    public double getLRDenFirstTermSum() {
      return LRDenFirstTermSum;
    }
    
    public HashMap<Double, Integer> getRandPOIProbs() { return rand_poi_probs; }
  }
  






  private static double calcPOIProb(Locus locus_name, ArrayList<STR_Allele> poi_genotype, double[] mix_ratio)
    throws InterruptedException, ExecutionException
  {
    double Prob = 0.0D;
    Double tempProb = Double.valueOf(NaN.0D);
    boolean not_reached = true;
    
    double Numerator = 0.0D;
    double genoSamples = 0.0D;
    
    int numOfIterations = interference_samples[(noc - 2)] / num_processors;
    
    while (not_reached)
    {
      ExecutorService executor = Executors.newFixedThreadPool(num_processors);
      
      Set<threadcalcPOIProbJob> Callables = new HashSet();
      
      for (int j = 1; j <= num_processors; j++) {
        Callables.add(new threadcalcPOIProbJob(numOfIterations, locus_name, poi_genotype, mix_ratio));
      }
      
      List<Future<Callable_threadcalcPOIProbJob_object>> Futures = executor.invokeAll(Callables);
      
      for (Future<Callable_threadcalcPOIProbJob_object> future : Futures) {
        Callable_threadcalcPOIProbJob_object clobject = (Callable_threadcalcPOIProbJob_object)future.get();
        Numerator += clobject.getNumValue();
      }
      

      executor.shutdown();
      
      genoSamples += interference_samples[(noc - 2)];
      
      double logProb = Math.log10(Numerator) - Math.log10(genoSamples);
      
      if (tempProb.doubleValue() == NaN.0D) {
        tempProb = Double.valueOf(logProb);



      }
      else if (logProb == Double.NEGATIVE_INFINITY) {
        Prob = logProb;
        not_reached = false;

      }
      else
      {
        double diff = Math.abs(logProb - tempProb.doubleValue());
        
        if (diff < genotype_tolerance) {
          Prob = logProb;
          not_reached = false;
        }
        else
        {
          tempProb = Double.valueOf(logProb);
        }
      }
    }
    
    return Prob;
  }
  





  private static double calcPOIProbAMEL(Locus locus_name, ArrayList<String> poi_genotype, double[] mix_ratio)
    throws InterruptedException, ExecutionException
  {
    double Prob = 0.0D;
    Double tempProb = Double.valueOf(NaN.0D);
    boolean not_reached = true;
    
    double Numerator = 0.0D;
    double genoSamples = 0.0D;
    
    int numOfIterations = interference_samples[(noc - 2)] / num_processors;
    
    while (not_reached)
    {
      ExecutorService executor = Executors.newFixedThreadPool(num_processors);
      
      Set<threadcalcPOIProbJobAMEL> Callables = new HashSet();
      
      for (int j = 1; j <= num_processors; j++) {
        Callables.add(new threadcalcPOIProbJobAMEL(numOfIterations, locus_name, poi_genotype, mix_ratio));
      }
      
      List<Future<Callable_threadcalcPOIProbJob_object>> Futures = executor.invokeAll(Callables);
      
      for (Future<Callable_threadcalcPOIProbJob_object> future : Futures) {
        Callable_threadcalcPOIProbJob_object clobject = (Callable_threadcalcPOIProbJob_object)future.get();
        Numerator += clobject.getNumValue();
      }
      

      executor.shutdown();
      genoSamples += interference_samples[(noc - 2)];
      
      double logProb = Math.log10(Numerator) - Math.log10(genoSamples);
      
      if (tempProb.doubleValue() == NaN.0D) {
        tempProb = Double.valueOf(logProb);



      }
      else if (logProb == Double.NEGATIVE_INFINITY) {
        Prob = logProb;
        not_reached = false;

      }
      else
      {
        double diff = Math.abs(logProb - tempProb.doubleValue());
        
        if (diff < genotype_tolerance) {
          Prob = logProb;
          not_reached = false;
        }
        else
        {
          tempProb = Double.valueOf(logProb);
        }
      }
    }
    
    return Prob;
  }
  

  private static class threadRandomPathJob
    implements Callable<CEESItAlgorithm.Callable_threadRandomPathJob_object>
  {
    private double true_p_value;
    
    private double LRDenSum;
    private final double numOfIterations;
    private HashMap<Double, Integer> randpoiprobs;
    
    threadRandomPathJob(double numOfIterations)
    {
      this.numOfIterations = numOfIterations;
      true_p_value = 0.0D;
      LRDenSum = 0.0D;
      randpoiprobs = new HashMap();
    }
    












    public CEESItAlgorithm.Callable_threadRandomPathJob_object call()
    {
      ArrayList<String> amelGeno = null;
      
      for (int i = 0; i < numOfIterations; i++)
      {
        HashMap<CEESItAlgorithm.Locus, ArrayList<CEESItAlgorithm.STR_Allele>> sampGeno = new HashMap();
        
        for (Iterator localIterator = CEESItAlgorithm.Working_Loci.iterator(); localIterator.hasNext();) { locus = (CEESItAlgorithm.Locus)localIterator.next();
          if (!locus.getName().contentEquals("AMEL")) {
            int final_value = ((Integer)CEESItAlgorithm.genoFreqDistFinalValues.get(locus)).intValue();
            int r = (int)Math.round(ThreadLocalRandom.current().nextDouble(1.0D) * final_value);
            ArrayList<CEESItAlgorithm.STR_Allele> locusGeno = (ArrayList)((LinkedHashMap)CEESItAlgorithm.genoFreqIntervals.get(locus)).get(Integer.valueOf(r));
            sampGeno.put(locus, locusGeno);
          }
          else {
            int genoIndex = ThreadLocalRandom.current().nextInt(((ArrayList)CEESItAlgorithm.AMELworkGenotypes.get(locus)).size());
            amelGeno = (ArrayList)((ArrayList)CEESItAlgorithm.AMELworkGenotypes.get(locus)).get(genoIndex);
          }
        }
        CEESItAlgorithm.Locus locus;
        double[] mixRatioProbs = new double[CEESItAlgorithm.mixRatios.size()];
        CEESItAlgorithm.Locus locus;
        for (int k = 0; k < CEESItAlgorithm.mixRatios.size(); k++)
        {
          double mixRatioProb = 0.0D;
          
          for (locus = CEESItAlgorithm.Working_Loci.iterator(); locus.hasNext();) { locus = (CEESItAlgorithm.Locus)locus.next();
            if (!locus.getName().contentEquals("AMEL")) {
              ArrayList<CEESItAlgorithm.STR_Allele> Geno = (ArrayList)sampGeno.get(locus);
              mixRatioProb += ((Double)((ArrayList)((HashMap)CEESItAlgorithm.genoProbs.get(locus)).get(Geno)).get(k)).doubleValue();
            }
            else {
              mixRatioProb += ((Double)((ArrayList)((HashMap)CEESItAlgorithm.AMELgenoProbs.get(locus)).get(amelGeno)).get(k)).doubleValue();
            }
          }
          
          mixRatioProbs[k] = mixRatioProb;
        }
        
        Arrays.sort(mixRatioProbs);
        double max = mixRatioProbs[(mixRatioProbs.length - 1)];
        double logGenoProb;
        double logGenoProb; if (max == Double.NEGATIVE_INFINITY) {
          logGenoProb = Double.NEGATIVE_INFINITY;
        }
        else {
          double sum = 0.0D;
          double[] arrayOfDouble1 = mixRatioProbs;locus = arrayOfDouble1.length; for (locus = 0; locus < locus; locus++) { double logValue = arrayOfDouble1[locus];
            double newLogValue = max - logValue;
            sum += Math.pow(10.0D, -newLogValue);
          }
          
          logGenoProb = max + Math.log10(sum) + CEESItAlgorithm.mrProb;
        }
        
        LRDenSum += Math.pow(10.0D, logGenoProb - CEESItAlgorithm.offset);
        
        double freshLogGenoProb = Math.round(logGenoProb);
        
        if (!randpoiprobs.containsKey(Double.valueOf(freshLogGenoProb))) {
          randpoiprobs.put(Double.valueOf(freshLogGenoProb), Integer.valueOf(1));
        }
        else {
          randpoiprobs.put(Double.valueOf(freshLogGenoProb), Integer.valueOf(((Integer)randpoiprobs.get(Double.valueOf(freshLogGenoProb))).intValue() + 1));
        }
        
        if (logGenoProb >= CEESItAlgorithm.truePoiProb.doubleValue()) {
          true_p_value += 1.0D;
        }
      }
      
      CEESItAlgorithm.Callable_threadRandomPathJob_object ctrpjobject = new CEESItAlgorithm.Callable_threadRandomPathJob_object(true_p_value, LRDenSum, randpoiprobs);
      return ctrpjobject;
    }
  }
  

  private static class threadcalcPOIProbJob
    implements Callable<CEESItAlgorithm.Callable_threadcalcPOIProbJob_object>
  {
    private final CEESItAlgorithm.Locus locus;
    
    private final int numOfIterations;
    private final ArrayList<CEESItAlgorithm.STR_Allele> poi_genotype;
    private double num_sum;
    private final double[] mix_ratio;
    
    threadcalcPOIProbJob(int numOfIterations, CEESItAlgorithm.Locus locus, ArrayList<CEESItAlgorithm.STR_Allele> poi_genotype, double[] mix_ratio)
    {
      this.numOfIterations = numOfIterations;
      this.poi_genotype = poi_genotype;
      this.locus = locus;
      this.mix_ratio = mix_ratio;
      num_sum = 0.0D;
    }
    












    public CEESItAlgorithm.Callable_threadcalcPOIProbJob_object call()
      throws MathException
    {
      for (int i = 1; i <= numOfIterations; i++)
      {
        ArrayList<CEESItAlgorithm.STR_Allele> alleles = new ArrayList();
        double[] masses = new double[CEESItAlgorithm.largestAllele + 1];
        
        double allele_prob = 1.0D;
        double height_prob = 1.0D;
        
        for (int j = 0; j < 2 * (CEESItAlgorithm.noc - 1); j++)
        {
          int final_value = ((Integer)CEESItAlgorithm.HeightsDist_Final_Values.get(locus.name)).intValue();
          int r = (int)Math.round(ThreadLocalRandom.current().nextDouble(1.0D) * final_value);
          CEESItAlgorithm.STR_Allele allele = (CEESItAlgorithm.STR_Allele)((LinkedHashMap)CEESItAlgorithm.Heights_Intervals.get(locus.name)).get(Integer.valueOf(r));
          
          if (!alleles.contains(allele)) {
            alleles.add(allele);
          }
          
          allele_prob *= ((Double)((LinkedHashMap)CEESItAlgorithm.Freq_Table.get(locus.name)).get(allele)).doubleValue();
          height_prob *= ((Double)((LinkedHashMap)CEESItAlgorithm.Loci_HeightsDist.get(locus.name)).get(allele)).doubleValue();
          
          int contrib = (int)Math.floor(j / 2);
          double mass = mix_ratio[contrib] * CEESItAlgorithm.DNA_Mass;
          
          masses[allele.getValue()] += mass;
        }
        

        for (CEESItAlgorithm.STR_Allele allele : poi_genotype)
        {
          if (!alleles.contains(allele)) {
            alleles.add(allele);
          }
          double mass = mix_ratio[(CEESItAlgorithm.noc - 1)] * CEESItAlgorithm.DNA_Mass;
          masses[allele.getValue()] += mass;
        }
        

        double signalProb = CEESItAlgorithm.calcLocusProbMostCombos(locus, alleles, masses);
        
        double weight = allele_prob / height_prob;
        
        num_sum += signalProb * weight;
      }
      

      CEESItAlgorithm.Callable_threadcalcPOIProbJob_object clobject = new CEESItAlgorithm.Callable_threadcalcPOIProbJob_object(num_sum);
      return clobject;
    }
  }
  

  private static class threadcalcPOIProbJobAMEL
    implements Callable<CEESItAlgorithm.Callable_threadcalcPOIProbJob_object>
  {
    private final CEESItAlgorithm.Locus locus;
    private final int numOfIterations;
    private final ArrayList<String> poi_genotype;
    private double num_sum;
    private final double[] mix_ratio;
    
    threadcalcPOIProbJobAMEL(int numOfIterations, CEESItAlgorithm.Locus locus, ArrayList<String> poi_genotype, double[] mix_ratio)
    {
      this.numOfIterations = numOfIterations;
      this.poi_genotype = poi_genotype;
      this.locus = locus;
      this.mix_ratio = mix_ratio;
      num_sum = 0.0D;
    }
    




    public CEESItAlgorithm.Callable_threadcalcPOIProbJob_object call()
    {
      for (int i = 1; i <= numOfIterations; i++)
      {
        ArrayList<String> alleles = new ArrayList();
        HashMap<String, Double> masses = new HashMap();
        
        for (int contrib = 0; contrib < CEESItAlgorithm.noc - 1; contrib++)
        {
          String sex = CEESItAlgorithm.Sexes[ThreadLocalRandom.current().nextInt(2)];
          
          for (String allele : (String[])CEESItAlgorithm.Sexes_Genotype.get(sex))
          {
            if (!alleles.contains(allele)) {
              alleles.add(allele);
            }
            
            double mass = mix_ratio[contrib] * CEESItAlgorithm.DNA_Mass;
            if (masses.containsKey(allele)) {
              masses.put(allele, Double.valueOf(((Double)masses.get(allele)).doubleValue() + mass));
            }
            else {
              masses.put(allele, Double.valueOf(mass));
            }
          }
        }
        

        for (String allele : poi_genotype)
        {
          if (!alleles.contains(allele)) {
            alleles.add(allele);
          }
          
          double mass = mix_ratio[(CEESItAlgorithm.noc - 1)] * CEESItAlgorithm.DNA_Mass;
          if (masses.containsKey(allele)) {
            masses.put(allele, Double.valueOf(((Double)masses.get(allele)).doubleValue() + mass));
          }
          else {
            masses.put(allele, Double.valueOf(mass));
          }
        }
        

        double signalProb = CEESItAlgorithm.calcLocusProbMostCombosAMEL(locus, alleles, masses);
        
        num_sum += signalProb;
      }
      

      CEESItAlgorithm.Callable_threadcalcPOIProbJob_object clobject = new CEESItAlgorithm.Callable_threadcalcPOIProbJob_object(num_sum);
      return clobject;
    }
  }
  









  private static double calcLocusProbMostCombos(Locus locus, ArrayList<STR_Allele> alleles, double[] masses)
    throws MathException
  {
    double prob = 1.0D;
    
    HashMap<STR_Allele, Peak> allObsPeaks = locus.getAllObsPeaks();
    
    double[] probFStutDOs = new double[largestAllele];
    double[] probRStutDOs = new double[largestAllele];
    double[] FStutMeans = new double[largestAllele];
    double[] FStutVariances = new double[largestAllele];
    double[] RStutMeans = new double[largestAllele];
    double[] RStutVariances = new double[largestAllele];
    
    double[] TMeanCalibs = locus.getTMeanCalibs();
    double[] TSDCalibs = locus.getTSDCalibs();
    double[] TDOCalibs = locus.getTDOCalibs();
    double[] NMeanCalibs = locus.getNMeanCalibs();
    double[] NSDCalibs = locus.getNSDCalibs();
    double NDO = locus.getNDOCalibs();
    double[] RMeanCalibs = locus.getRMeanCalibs();
    double[] RSDCalibs = locus.getRSDCalibs();
    double[] RDOCalibs = locus.getRDOCalibs();
    double[] FMeanCalibs = locus.getFMeanCalibs();
    double[] FSDCalibs = locus.getFSDCalibs();
    double[] FDOCalibs = locus.getFDOCalibs();
    
    ArrayList<STR_Allele> trueAlleles = new ArrayList(alleles);
    ArrayList<STR_Allele> rStutterAlleles = new ArrayList();
    ArrayList<STR_Allele> fStutterAlleles = new ArrayList();
    
    for (STR_Allele allele : trueAlleles)
    {
      if (allObsPeaks.containsKey(allele))
      {
        STR_Allele fowAllele = new STR_Allele(allele.getFStutAllele());
        STR_Allele revAllele = new STR_Allele(allele.getRStutAllele());
        
        rStutterAlleles.add(revAllele);
        fStutterAlleles.add(fowAllele);
      }
    }
    

    for (STR_Allele allele : fStutterAlleles)
    {
      STR_Allele fowStutParentAllele = new STR_Allele(allele.getFParent());
      double fowStutParentMass = masses[fowStutParentAllele.getValue()];
      
      Peak fowStutParentPeak = (Peak)allObsPeaks.get(fowStutParentAllele);
      int fowStutParentHeight = fowStutParentPeak.getHeight();
      
      double fstut_mean = calcTwoExpValue(FMeanCalibs, fowStutParentMass) * fowStutParentHeight;
      double fstut_stddev = calcTwoExpValue(FSDCalibs, fowStutParentMass) * fowStutParentHeight;
      double fstut_variance = fstut_stddev * fstut_stddev;
      
      double probFStutDO = Math.min(1.0D, calcExpValue(FDOCalibs, fowStutParentMass));
      
      probFStutDOs[allele.getValue()] = probFStutDO;
      
      FStutMeans[allele.getValue()] = fstut_mean;
      FStutVariances[allele.getValue()] = fstut_variance;
    }
    
    for (STR_Allele allele : rStutterAlleles)
    {
      STR_Allele revStutParentAllele = new STR_Allele(allele.getRParent());
      double revStutParentMass = masses[revStutParentAllele.getValue()];
      
      revStutParentPeak = (Peak)allObsPeaks.get(revStutParentAllele);
      int revStutParentHeight = revStutParentPeak.getHeight();
      
      double rstut_mean = calcTwoExpValue(RMeanCalibs, revStutParentMass) * revStutParentHeight;
      double rstut_stddev = calcTwoExpValue(RSDCalibs, revStutParentMass) * revStutParentHeight;
      double rstut_variance = rstut_stddev * rstut_stddev;
      
      double probRStutDO = Math.min(1.0D, calcExpValue(RDOCalibs, revStutParentMass));
      
      probRStutDOs[allele.getValue()] = probRStutDO;
      
      RStutMeans[allele.getValue()] = rstut_mean;
      RStutVariances[allele.getValue()] = rstut_variance;
    }
    Peak revStutParentPeak;
    double[] noise_values = calcTwoSlopeValue(DNA_Mass, NMeanCalibs, NSDCalibs);
    double noise_mean = noise_values[0];
    double noise_variance = noise_values[1] * noise_values[1];
    
    for (STR_Allele allele : locus.getAllPossAlleles())
    {
      int height = 0;
      if (allObsPeaks.containsKey(allele)) {
        height = ((Peak)allObsPeaks.get(allele)).getHeight();
      }
      






      double alleleProb = 0.0D;
      







      if (trueAlleles.contains(allele))
      {
        double mass = masses[allele.getValue()];
        
        double[] true_values = calcTwoSlopeValue(mass, TMeanCalibs, TSDCalibs);
        
        double true_mean = true_values[0];
        double true_variance = true_values[1] * true_values[1];
        
        double probDO = Math.min(1.0D, calcExpValue(TDOCalibs, mass));
        
        if (rStutterAlleles.contains(allele))
        {
          double probRStutDO = probRStutDOs[allele.getValue()];
          
          double rstut_mean = RStutMeans[allele.getValue()];
          double rstut_variance = RStutVariances[allele.getValue()];
          
          if (allObsPeaks.containsKey(allele)) {
            alleleProb = calcComboProbs2(probDO, probRStutDO, true_mean, rstut_mean, true_variance, rstut_variance, height);
          }
          else
          {
            alleleProb = probDO * probRStutDO;

          }
          

        }
        else if (allObsPeaks.containsKey(allele)) {
          alleleProb = (1.0D - probDO) * calcPeakHeightProb(height, true_mean, true_variance);
        }
        else
        {
          alleleProb = probDO;
        }
        

      }
      else if (rStutterAlleles.contains(allele))
      {
        double probRStutDO = probRStutDOs[allele.getValue()];
        double rstut_mean = RStutMeans[allele.getValue()];
        double rstut_variance = RStutVariances[allele.getValue()];
        
        if (fStutterAlleles.contains(allele))
        {
          double probFStutDO = probFStutDOs[allele.getValue()];
          double fstut_mean = FStutMeans[allele.getValue()];
          double fstut_variance = FStutVariances[allele.getValue()];
          
          if (allObsPeaks.containsKey(allele)) {
            alleleProb = calcComboProbs2(probRStutDO, probFStutDO, rstut_mean, fstut_mean, rstut_variance, fstut_variance, height);
          }
          else {
            alleleProb = probRStutDO * probFStutDO;

          }
          

        }
        else if (allObsPeaks.containsKey(allele)) {
          alleleProb = (1.0D - probRStutDO) * calcPeakHeightProb(height, rstut_mean, rstut_variance);
        }
        else {
          alleleProb = probRStutDO;
        }
        

      }
      else if (fStutterAlleles.contains(allele))
      {
        double probFStutDO = probFStutDOs[allele.getValue()];
        double fstut_mean = FStutMeans[allele.getValue()];
        double fstut_variance = FStutVariances[allele.getValue()];
        
        if (allObsPeaks.containsKey(allele)) {
          alleleProb = (1.0D - probFStutDO) * calcPeakHeightProb(height, fstut_mean, fstut_variance);
        }
        else
        {
          alleleProb = probFStutDO;

        }
        

      }
      else if (allObsPeaks.containsKey(allele)) {
        alleleProb = (1.0D - NDO) * calcPeakHeightProb(height, noise_mean, noise_variance);
      }
      else
      {
        alleleProb = NDO;
      }
      

      prob *= alleleProb;
    }
    

    if (prob < 0.0D) {
      prob = 0.0D;
    }
    
    return prob;
  }
  










  private static double calcLocusProbMostCombosAMEL(Locus locus, ArrayList<String> alleles, HashMap<String, Double> masses)
  {
    double prob = 1.0D;
    
    HashMap<String, AMEL_Peak> allObsPeaks = (HashMap)AMEL_Peaks.get(locus.getName());
    
    double[] TMeanCalibs = locus.getTMeanCalibs();
    double[] TSDCalibs = locus.getTSDCalibs();
    double[] TDOCalibs = locus.getTDOCalibs();
    double[] NMeanCalibs = locus.getNMeanCalibs();
    double[] NSDCalibs = locus.getNSDCalibs();
    double NDO = locus.getNDOCalibs();
    
    ArrayList<String> trueAlleles = new ArrayList(alleles);
    
    double[] noise_values = calcTwoSlopeValue(DNA_Mass, NMeanCalibs, NSDCalibs);
    double noise_mean = noise_values[0];
    double noise_variance = noise_values[1] * noise_values[1];
    
    for (String allele : (String[])Sexes_Genotype.get("M"))
    {
      int height = 0;
      if (allObsPeaks.containsKey(allele)) {
        height = ((AMEL_Peak)allObsPeaks.get(allele)).getHeight();
      }
      




      double alleleProb = 0.0D;
      



      if (trueAlleles.contains(allele))
      {
        double mass = ((Double)masses.get(allele)).doubleValue();
        
        double[] true_values = calcTwoSlopeValue(mass, TMeanCalibs, TSDCalibs);
        
        double true_mean = true_values[0];
        double true_variance = true_values[1] * true_values[1];
        
        double probDO = Math.min(1.0D, calcExpValue(TDOCalibs, mass));
        
        if (allObsPeaks.containsKey(allele)) {
          alleleProb = (1.0D - probDO) * calcPeakHeightProb(height, true_mean, true_variance);
        }
        else
        {
          alleleProb = probDO;

        }
        

      }
      else if (allObsPeaks.containsKey(allele)) {
        alleleProb = (1.0D - NDO) * calcPeakHeightProb(height, noise_mean, noise_variance);
      }
      else
      {
        alleleProb = NDO;
      }
      
      prob *= alleleProb;
    }
    

    if (prob < 0.0D) {
      prob = 0.0D;
    }
    
    return prob;
  }
  








  private static double calcPeakHeightProb(int height, double mean, double variance)
  {
    double first_term = 1.0D / Math.sqrt(twoPi * variance);
    
    double second_term = Math.exp(-0.5D * (height - mean) * (height - mean) / variance);
    
    return first_term * second_term;
  }
  








  private static double calcComboProbs2(double probdo1, double probdo2, double mean1, double mean2, double variance1, double variance2, int height)
  {
    double combo1Prob = calcPeakHeightProb(height, mean1 + mean2, variance1 + variance2) * (1.0D - probdo1) * (1.0D - probdo2);
    
    double combo2Prob = calcPeakHeightProb(height, mean1, variance1) * (1.0D - probdo1) * probdo2;
    
    double combo3Prob = calcPeakHeightProb(height, mean2, variance2) * (1.0D - probdo2) * probdo1;
    
    return combo1Prob + combo2Prob + combo3Prob;
  }
  

  private static abstract class Allele
  {
    private Allele() {}
    

    public abstract int hashCode();
    

    public abstract boolean equals(Object paramObject);
    

    public abstract String toString();
  }
  

  private static class STR_Allele
    extends CEESItAlgorithm.Allele
  {
    private int value;
    
    private final int rStutAllele;
    
    private final int fStutAllele;
    
    private final int fParent;
    
    private final int rParent;
    
    STR_Allele(String value)
    {
      super();
      this.value = ((int)(Double.parseDouble(value) * 10.0D));
      fStutAllele = (this.value + 10);
      rStutAllele = (this.value - 10);
      fParent = (this.value - 10);
      rParent = (this.value + 10);
    }
    
    STR_Allele(int value) { super();
      this.value = value;
      fStutAllele = (this.value + 10);
      rStutAllele = (this.value - 10);
      fParent = (this.value - 10);
      rParent = (this.value + 10);
    }
    
    public int hashCode()
    {
      return value;
    }
    
    public boolean equals(Object o)
    {
      if ((o instanceof STR_Allele)) {
        STR_Allele c = (STR_Allele)o;
        if (value == value) {
          return true;
        }
      }
      return false;
    }
    
    public String toString()
    {
      return String.valueOf(value);
    }
    
    public int getValue() {
      return value;
    }
    
    public int getRStutAllele() {
      return rStutAllele;
    }
    
    public int getFStutAllele() {
      return fStutAllele;
    }
    
    public int getRParent() {
      return rParent;
    }
    
    public int getFParent() {
      return fParent;
    }
    
    public void setValue(int value) {
      this.value = value;
    }
  }
  

  private static class Locus
  {
    private final String name;
    
    private final HashMap<CEESItAlgorithm.STR_Allele, CEESItAlgorithm.Peak> allobspeaks;
    private final HashSet<CEESItAlgorithm.STR_Allele> allpossalleles;
    private final LinkedHashMap<Integer, CEESItAlgorithm.STR_Allele> heightsintervals;
    private final LinkedHashMap<CEESItAlgorithm.STR_Allele, Double> freqtable;
    private final LinkedHashMap<CEESItAlgorithm.STR_Allele, Double> heightsdist;
    private final double[] tmeancalibs;
    private final double[] tsdcalibs;
    private final double[] tdocalibs;
    private final double[] nmeancalibs;
    private final double[] nsdcalibs;
    private final double ndocalibs;
    private final double[] rmeancalibs;
    private final double[] rsdcalibs;
    private final double[] rdocalibs;
    private final double[] fmeancalibs;
    private final double[] fsdcalibs;
    private final double[] fdocalibs;
    
    Locus(String name, HashMap<CEESItAlgorithm.STR_Allele, CEESItAlgorithm.Peak> allobspeaks, HashSet<CEESItAlgorithm.STR_Allele> allpossalleles, LinkedHashMap<Integer, CEESItAlgorithm.STR_Allele> heightsintervals, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double> freqtable, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double> heightsdist, double[] tmeancalibs, double[] tsdcalibs, double[] tdocalibs, double[] nmeancalibs, double[] nsdcalibs, double ndocalibs, double[] rmeancalibs, double[] rsdcalibs, double[] rdocalibs, double[] fmeancalibs, double[] fsdcalibs, double[] fdocalibs)
    {
      this.name = name;
      this.allobspeaks = allobspeaks;
      this.allpossalleles = allpossalleles;
      this.heightsintervals = heightsintervals;
      this.freqtable = freqtable;
      this.heightsdist = heightsdist;
      this.tmeancalibs = tmeancalibs;
      this.tsdcalibs = tsdcalibs;
      this.tdocalibs = tdocalibs;
      this.nmeancalibs = nmeancalibs;
      this.nsdcalibs = nsdcalibs;
      this.ndocalibs = ndocalibs;
      this.rmeancalibs = rmeancalibs;
      this.rsdcalibs = rsdcalibs;
      this.rdocalibs = rdocalibs;
      this.fmeancalibs = fmeancalibs;
      this.fsdcalibs = fsdcalibs;
      this.fdocalibs = fdocalibs;
    }
    
    public String getName() {
      return name;
    }
    
    public HashMap<CEESItAlgorithm.STR_Allele, CEESItAlgorithm.Peak> getAllObsPeaks() { return allobspeaks; }
    
    public HashSet<CEESItAlgorithm.STR_Allele> getAllPossAlleles() {
      return allpossalleles;
    }
    
    public LinkedHashMap<Integer, CEESItAlgorithm.STR_Allele> getHeightsIntervals() { return heightsintervals; }
    
    public LinkedHashMap<CEESItAlgorithm.STR_Allele, Double> getFreqTable() {
      return freqtable;
    }
    
    public LinkedHashMap<CEESItAlgorithm.STR_Allele, Double> getHeightsDist() { return heightsdist; }
    
    public double[] getTMeanCalibs() {
      return tmeancalibs;
    }
    
    public double[] getTSDCalibs() { return tsdcalibs; }
    
    public double[] getTDOCalibs() {
      return tdocalibs;
    }
    
    public double[] getNMeanCalibs() { return nmeancalibs; }
    
    public double[] getNSDCalibs() {
      return nsdcalibs;
    }
    
    public double getNDOCalibs() { return ndocalibs; }
    
    public double[] getRMeanCalibs() {
      return rmeancalibs;
    }
    
    public double[] getRSDCalibs() { return rsdcalibs; }
    
    public double[] getRDOCalibs() {
      return rdocalibs;
    }
    
    public double[] getFMeanCalibs() { return fmeancalibs; }
    
    public double[] getFSDCalibs() {
      return fsdcalibs;
    }
    
    public double[] getFDOCalibs() { return fdocalibs; }
  }
  
  public static boolean everythingOK()
  {
    boolean ok = false;
    if ((calibOK == true) && (sampleOK == true) && (freqOK == true) && (poiFileOK == true)) {
      ok = true;
    }
    return ok;
  }
  








  private static LinkedHashMap<String, LinkedHashMap<Integer, STR_Allele>> Intervals(LinkedHashMap<String, LinkedHashMap<STR_Allele, Double>> dist, ArrayList<String> locilist)
  {
    LinkedHashMap<String, LinkedHashMap<Integer, STR_Allele>> intervals_map = new LinkedHashMap();
    LinkedHashMap<String, LinkedHashMap<STR_Allele, int[]>> endpoints_map = new LinkedHashMap();
    for (int i = 0; i < locilist.size(); i++) {
      intervals_map.put(locilist.get(i), new LinkedHashMap());
      endpoints_map.put(locilist.get(i), new LinkedHashMap());
    }
    
    for (i = dist.keySet().iterator(); i.hasNext();) { locus = (String)i.next();
      STR_Allele[] keys_array = new STR_Allele[((LinkedHashMap)dist.get(locus)).size()];
      double[] values_array = new double[((LinkedHashMap)dist.get(locus)).size()];
      
      int counter = 0;
      for (STR_Allele allele : ((LinkedHashMap)dist.get(locus)).keySet()) {
        keys_array[counter] = allele;
        values_array[counter] = ((Double)((LinkedHashMap)dist.get(locus)).get(allele)).doubleValue();
        counter++;
      }
      int count = 0;
      while (count < keys_array.length) {
        if (count == 0) {
          ((LinkedHashMap)endpoints_map.get(locus)).put(keys_array[count], new int[] { 0, (int)Math.round(10000.0D * values_array[count]) - 1 });
        }
        else {
          init_value = ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(keys_array[(count - 1)]))[1] + 1;
          ((LinkedHashMap)endpoints_map.get(locus)).put(keys_array[count], new int[] { init_value, init_value + (int)Math.round(10000.0D * values_array[count]) - 1 });
        }
        count++;
      }
      for (STR_Allele allele : ((LinkedHashMap)endpoints_map.get(locus)).keySet()) {
        int i = ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(allele))[0];
        while (i <= ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(allele))[1]) {
          ((LinkedHashMap)intervals_map.get(locus)).put(Integer.valueOf(i), allele);
          i++;
        } } }
    String locus;
    int init_value;
    return intervals_map;
  }
  








  private static LinkedHashMap<Locus, LinkedHashMap<Integer, ArrayList<STR_Allele>>> GenotypeIntervals(LinkedHashMap<Locus, LinkedHashMap<ArrayList<STR_Allele>, Double>> dist, ArrayList<Locus> locilist)
  {
    LinkedHashMap<Locus, LinkedHashMap<Integer, ArrayList<STR_Allele>>> intervals_map = new LinkedHashMap();
    LinkedHashMap<Locus, LinkedHashMap<ArrayList<STR_Allele>, int[]>> endpoints_map = new LinkedHashMap();
    
    for (int i = 0; i < locilist.size(); i++) {
      intervals_map.put(locilist.get(i), new LinkedHashMap());
      endpoints_map.put(locilist.get(i), new LinkedHashMap());
    }
    
    for (i = dist.keySet().iterator(); i.hasNext();) { locus = (Locus)i.next();
      ArrayList<ArrayList<STR_Allele>> keys_array = new ArrayList();
      double[] values_array = new double[((LinkedHashMap)dist.get(locus)).size()];
      
      int counter = 0;
      for (ArrayList<STR_Allele> geno : ((LinkedHashMap)dist.get(locus)).keySet()) {
        keys_array.add(geno);
        values_array[counter] = ((Double)((LinkedHashMap)dist.get(locus)).get(geno)).doubleValue();
        counter++;
      }
      int count = 0;
      while (count < keys_array.size()) {
        if (count == 0) {
          ((LinkedHashMap)endpoints_map.get(locus)).put(keys_array.get(count), new int[] { 0, (int)Math.round(10000.0D * values_array[count]) - 1 });
        }
        else {
          init_value = ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(keys_array.get(count - 1)))[1] + 1;
          ((LinkedHashMap)endpoints_map.get(locus)).put(keys_array.get(count), new int[] { init_value, init_value + (int)Math.round(10000.0D * values_array[count]) - 1 });
        }
        count++;
      }
      for (ArrayList<STR_Allele> geno : ((LinkedHashMap)endpoints_map.get(locus)).keySet()) {
        int i = ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(geno))[0];
        while (i <= ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(geno))[1]) {
          ((LinkedHashMap)intervals_map.get(locus)).put(Integer.valueOf(i), geno);
          i++;
        } } }
    Locus locus;
    int init_value;
    return intervals_map;
  }
  







  private static double[] calcTwoSlopeValue(double xValue, double[] meanCalibValues, double[] SDCalibValues)
  {
    double mean = meanCalibValues[0] * xValue + meanCalibValues[1];
    double stddev = SDCalibValues[0] * xValue + SDCalibValues[1];
    
    return new double[] { mean, stddev };
  }
  





  private static double calcExpValue(double[] calibValues, double xValue)
  {
    return calibValues[0] * Math.exp(calibValues[1] * xValue);
  }
  







  private static double calcTwoExpValue(double[] calibValues, double xValue)
  {
    return calibValues[0] * Math.exp(calibValues[1] * xValue) + calibValues[2];
  }
  
  private static class LinFunction implements ParametricRealFunction
  {
    private LinFunction() {}
    
    public double[] gradient(double x, double[] parameters)
    {
      double a_grad = x;
      double b_grad = 1.0D;
      double[] grad = { a_grad, b_grad };
      return grad;
    }
    
    public double value(double x, double[] parameters) {
      double a = parameters[0];
      double b = parameters[1];
      return a * x + b;
    }
  }
  
  private static class ExpFunction implements ParametricRealFunction {
    private ExpFunction() {}
    
    public double[] gradient(double x, double[] parameters) {
      double a = parameters[0];
      double b = parameters[1];
      double a_grad = Math.exp(b * x);
      double b_grad = a * x * Math.exp(b * x);
      double[] grad = { a_grad, b_grad };
      return grad;
    }
    
    public double value(double x, double[] parameters) {
      double a = parameters[0];
      double b = parameters[1];
      return a * Math.exp(b * x);
    }
  }
  
  private static class TwoExpFunction implements ParametricRealFunction {
    private TwoExpFunction() {}
    
    public double[] gradient(double x, double[] parameters) {
      double a = parameters[0];
      double b = parameters[1];
      double a_grad = Math.exp(b * x);
      double b_grad = a * x * Math.exp(b * x);
      double c_grad = 1.0D;
      double[] grad = { a_grad, b_grad, c_grad };
      return grad;
    }
    
    public double value(double x, double[] parameters) {
      return parameters[0] * Math.exp(parameters[1] * x) + parameters[2];
    }
  }
  

  private static class CalibDataCollection
  {
    private boolean allOK;
    
    private final String calib_path;
    
    private HashSet<String> calibLoci;
    private HashSet<Double> masses;
    private LinkedHashMap<String, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double>> freq_table;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> trueCalibData;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> noiseCalibData;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> rstutterCalibData;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> fstutterCalibData;
    private HashMap<Double, HashMap<String, Double>> rstutterDOCalibData;
    private HashMap<Double, HashMap<String, Double>> fstutterDOCalibData;
    private HashMap<Double, HashMap<String, Double>> dropoutCalibData;
    private HashMap<Double, HashMap<String, Double>> noiseDOCalibData;
    
    CalibDataCollection(String calibpath, LinkedHashMap<String, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double>> freqtable)
    {
      calib_path = calibpath;
      freq_table = freqtable;
      dropoutCalibData = new HashMap();
      noiseDOCalibData = new HashMap();
      rstutterDOCalibData = new HashMap();
      fstutterDOCalibData = new HashMap();
      rstutterCalibData = new HashMap();
      fstutterCalibData = new HashMap();
      noiseCalibData = new HashMap();
      trueCalibData = new HashMap();
      calibLoci = new HashSet();
      masses = new HashSet();
      allOK = true;
      
      HashMap<Double, HashMap<String, ArrayList<Integer>>> trueValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> noiseValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Double>>> rstutterValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Double>>> fstutterValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> rstutterDO = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> fstutterDO = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> dropout = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> noiseDO = new HashMap();
      String line;
      ArrayList<String> loci_alleles_refresh;
      int height; try { CEESItAlgorithm.OpenAndReadFile calibFile = new CEESItAlgorithm.OpenAndReadFile(calib_path);
        String[] calibFileLines = calibFile.FileContents();
        String locus;
        for (int i = 1; i < calibFileLines.length; i++) {
          String line = calibFileLines[i];
          String[] lineParts = line.split(",");
          if (lineParts.length < 6) {
            JOptionPane.showMessageDialog(null, "Calibration file does not have the right format");
            allOK = false;
            return;
          }
          locus = lineParts[4];
          calibLoci.add(locus);
          try
          {
            mass = Double.parseDouble(lineParts[1]);
          } catch (NumberFormatException e) {
            double mass;
            JOptionPane.showMessageDialog(null, "DNA mass should be a number in the calibration file");
            allOK = false; return;
          }
          double mass;
          masses.add(Double.valueOf(mass));
        }
        for (i = masses.iterator(); i.hasNext();) { mass = ((Double)i.next()).doubleValue();
          trueValues.put(Double.valueOf(mass), new HashMap());
          noiseValues.put(Double.valueOf(mass), new HashMap());
          rstutterValues.put(Double.valueOf(mass), new HashMap());
          fstutterValues.put(Double.valueOf(mass), new HashMap());
          dropout.put(Double.valueOf(mass), new HashMap());
          rstutterDO.put(Double.valueOf(mass), new HashMap());
          fstutterDO.put(Double.valueOf(mass), new HashMap());
          noiseDO.put(Double.valueOf(mass), new HashMap());
          dropoutCalibData.put(Double.valueOf(mass), new HashMap());
          noiseDOCalibData.put(Double.valueOf(mass), new HashMap());
          rstutterDOCalibData.put(Double.valueOf(mass), new HashMap());
          fstutterDOCalibData.put(Double.valueOf(mass), new HashMap());
          trueCalibData.put(Double.valueOf(mass), new HashMap());
          noiseCalibData.put(Double.valueOf(mass), new HashMap());
          rstutterCalibData.put(Double.valueOf(mass), new HashMap());
          fstutterCalibData.put(Double.valueOf(mass), new HashMap());
          for (locus = calibLoci.iterator(); locus.hasNext();) { locus = (String)locus.next();
            ((HashMap)trueValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)noiseValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)rstutterValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)fstutterValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)dropout.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)rstutterDO.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)fstutterDO.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)noiseDO.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)trueCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)noiseCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)rstutterCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)fstutterCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList()); } }
        double mass;
        String locus;
        for (int i = 1; i < calibFileLines.length; i++) {
          line = calibFileLines[i];
          String[] lineParts = line.split(",");
          List<String> line_refresh = new ArrayList();
          locus = lineParts;NumberFormatException localNumberFormatException1 = locus.length; for (e = 0; e < localNumberFormatException1; e++) { String element = locus[e];
            if (element != null) {
              line_refresh.add(element);
            }
          }
          String locus = (String)line_refresh.get(4);
          double mass = Double.parseDouble((String)line_refresh.get(1));
          CEESItAlgorithm.Peak obj; if (!locus.contentEquals("AMEL")) {
            ArrayList<CEESItAlgorithm.Peak> loci_peaks = new ArrayList();
            ArrayList<CEESItAlgorithm.STR_Allele> loci_alleles = new ArrayList();
            ArrayList<CEESItAlgorithm.Peak> loci_peaks_refresh = new ArrayList();
            ArrayList<CEESItAlgorithm.STR_Allele> loci_alleles_refresh = new ArrayList();
            ArrayList<CEESItAlgorithm.STR_Allele> peakalleles_deleted = new ArrayList();
            ArrayList<CEESItAlgorithm.Peak> peaks_tobedeleted = new ArrayList();
            Set<CEESItAlgorithm.STR_Allele> trueAlleles = new HashSet();
            Set<CEESItAlgorithm.STR_Allele> true_Stutter_Alleles = new HashSet();
            
            try
            {
              Double.parseDouble((String)line_refresh.get(2));
            }
            catch (NumberFormatException e) {
              JOptionPane.showMessageDialog(null, "Genotype allele should be a number in the calibration file");
              allOK = false;
              return;
            }
            CEESItAlgorithm.STR_Allele trueallele1 = new CEESItAlgorithm.STR_Allele((String)line_refresh.get(2));
            try
            {
              Double.parseDouble((String)line_refresh.get(3));
            }
            catch (NumberFormatException e) {
              JOptionPane.showMessageDialog(null, "Genotype allele should be a number in the calibration file");
              allOK = false;
              return;
            }
            CEESItAlgorithm.STR_Allele trueallele2 = new CEESItAlgorithm.STR_Allele((String)line_refresh.get(3));
            if (trueallele1.getValue() - trueallele2.getValue() != 0) {
              trueAlleles.add(trueallele1);
              trueAlleles.add(trueallele2);
              
              int j = 6;
              while (j < line_refresh.size()) {
                if (!((String)line_refresh.get(j)).equals("OL")) {
                  try {
                    Double.parseDouble((String)line_refresh.get(j));
                  }
                  catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Allele should be a real number in the calibration file");
                    allOK = false;
                    return;
                  }
                  allele = new CEESItAlgorithm.STR_Allele((String)line_refresh.get(j));
                  try
                  {
                    height = Integer.parseInt((String)line_refresh.get(j + 2));
                  } catch (NumberFormatException e) {
                    int height;
                    JOptionPane.showMessageDialog(null, "Height should be an integer in the calibration file");
                    allOK = false; return;
                  }
                  int height;
                  CEESItAlgorithm.Peak peakobject = new CEESItAlgorithm.Peak(allele, height);
                  loci_peaks.add(peakobject);
                  loci_alleles.add(peakobject.getAllele());
                }
                j += 3;
              }
              
              for (CEESItAlgorithm.STR_Allele allele = loci_peaks.iterator(); allele.hasNext();) { peakobj1 = (CEESItAlgorithm.Peak)allele.next();
                allele1 = peakobj1.getAllele();
                int count = Collections.frequency(loci_alleles, allele1);
                if (count > 1)
                  for (CEESItAlgorithm.Peak peakobj2 : loci_peaks) {
                    CEESItAlgorithm.STR_Allele allele2 = peakobj2.getAllele();
                    if (allele1 == allele2) {
                      index1 = loci_peaks.indexOf(peakobj1);
                      int index2 = loci_peaks.indexOf(peakobj2);
                      if (index1 != index2) {
                        int h1 = peakobj1.getHeight();
                        int h2 = peakobj2.getHeight();
                        if (h1 >= h2) {
                          if (!peakalleles_deleted.contains(allele2)) {
                            peaks_tobedeleted.add(peakobj2);
                            peakalleles_deleted.add(allele2);
                          }
                          
                        }
                        else if (!peakalleles_deleted.contains(allele1)) {
                          peaks_tobedeleted.add(peakobj1);
                          peakalleles_deleted.add(allele1);
                        }
                      }
                    }
                  }
              }
              CEESItAlgorithm.Peak peakobj1;
              CEESItAlgorithm.STR_Allele allele1;
              int index1;
              for (CEESItAlgorithm.Peak peakobj : loci_peaks) {
                if (!peaks_tobedeleted.contains(peakobj)) {
                  loci_peaks_refresh.add(peakobj);
                  loci_alleles_refresh.add(peakobj.getAllele());
                }
              }
              for (CEESItAlgorithm.STR_Allele allele : trueAlleles)
              {
                true_Stutter_Alleles.add(allele);
                rev_allele = new CEESItAlgorithm.STR_Allele(allele.getRStutAllele());
                CEESItAlgorithm.STR_Allele fow_allele = new CEESItAlgorithm.STR_Allele(allele.getFStutAllele());
                if (loci_alleles_refresh.contains(allele)) {
                  for (CEESItAlgorithm.Peak peakobj : loci_peaks_refresh) {
                    if (peakobj.getAllele().getValue() - allele.getValue() == 0) {
                      int height = peakobj.getHeight();
                      ((ArrayList)((HashMap)trueValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(height));
                      ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                    }
                  }
                  int parent_height;
                  if (loci_alleles_refresh.contains(rev_allele)) {
                    true_Stutter_Alleles.add(rev_allele);
                    if ((!trueAlleles.contains(rev_allele)) && (!trueAlleles.contains(new CEESItAlgorithm.STR_Allele(rev_allele.getFParent())))) {
                      for (CEESItAlgorithm.Peak peakobj : loci_peaks_refresh) {
                        if (peakobj.getAllele().getValue() - allele.getValue() == 0) {
                          parent_height = peakobj.getHeight();
                          for (CEESItAlgorithm.Peak peakobj2 : loci_peaks_refresh) {
                            CEESItAlgorithm.STR_Allele stut_allele = peakobj2.getAllele();
                            if (stut_allele.getValue() - rev_allele.getValue() == 0) {
                              int stut_height = peakobj2.getHeight();
                              double stut_ratio = stut_height / parent_height;
                              ((ArrayList)((HashMap)rstutterValues.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(stut_ratio));
                              ((ArrayList)((HashMap)rstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                            }
                          }
                        }
                      }
                    }
                  }
                  else {
                    ((ArrayList)((HashMap)rstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                  }
                  int parent_height;
                  if (loci_alleles_refresh.contains(fow_allele)) {
                    true_Stutter_Alleles.add(fow_allele);
                    if ((!trueAlleles.contains(fow_allele)) && (!trueAlleles.contains(new CEESItAlgorithm.STR_Allele(fow_allele.getRParent())))) {
                      for (CEESItAlgorithm.Peak peakobj : loci_peaks_refresh) {
                        if (peakobj.getAllele().getValue() - allele.getValue() == 0) {
                          parent_height = peakobj.getHeight();
                          for (CEESItAlgorithm.Peak peakobj2 : loci_peaks_refresh) {
                            CEESItAlgorithm.STR_Allele stut_allele = peakobj2.getAllele();
                            if (stut_allele.getValue() - fow_allele.getValue() == 0) {
                              int stut_height = peakobj2.getHeight();
                              double stut_ratio = stut_height / parent_height;
                              ((ArrayList)((HashMap)fstutterValues.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(stut_ratio));
                              ((ArrayList)((HashMap)fstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                            }
                          }
                        }
                      }
                    }
                  }
                  else {
                    ((ArrayList)((HashMap)fstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                  }
                }
                else
                {
                  ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                } }
              CEESItAlgorithm.STR_Allele rev_allele;
              if (freq_table.containsKey(locus)) {
                for (CEESItAlgorithm.STR_Allele allele : (HashSet)CEESItAlgorithm.AllPossibleAlleles.get(locus)) {
                  if (!true_Stutter_Alleles.contains(allele)) {
                    if (loci_alleles_refresh.contains(allele)) {
                      for (rev_allele = loci_peaks_refresh.iterator(); rev_allele.hasNext();) { obj = (CEESItAlgorithm.Peak)rev_allele.next();
                        CEESItAlgorithm.STR_Allele a = obj.getAllele();
                        if (a.getValue() - allele.getValue() == 0) {
                          ((ArrayList)((HashMap)noiseValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(obj.getHeight()));
                          ((ArrayList)((HashMap)noiseDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                        }
                        
                      }
                    } else {
                      ((ArrayList)((HashMap)noiseDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                    }
                    
                  }
                }
              } else {
                ((ArrayList)((HashMap)noiseDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
              }
            }
          }
          else
          {
            ArrayList<CEESItAlgorithm.AMEL_Peak> loci_peaks = new ArrayList();
            ArrayList<String> loci_alleles = new ArrayList();
            ArrayList<CEESItAlgorithm.AMEL_Peak> loci_peaks_refresh = new ArrayList();
            loci_alleles_refresh = new ArrayList();
            ArrayList<String> peakalleles_deleted = new ArrayList();
            ArrayList<CEESItAlgorithm.AMEL_Peak> peaks_tobedeleted = new ArrayList();
            Set<String> trueAlleles = new HashSet();
            
            String trueallele1 = (String)line_refresh.get(2);
            if ((!trueallele1.contentEquals("X")) && (!trueallele1.contentEquals("Y"))) {
              JOptionPane.showMessageDialog(null, "AMEL genotype allele should be X or Y in the calibration file");
              allOK = false;
              return;
            }
            String trueallele2 = (String)line_refresh.get(3);
            if ((!trueallele2.contentEquals("X")) && (!trueallele2.contentEquals("Y"))) {
              JOptionPane.showMessageDialog(null, "AMEL genotype allele should be X or Y in the calibration file");
              allOK = false;
              return;
            }
            
            trueAlleles.add(trueallele1);
            trueAlleles.add(trueallele2);
            
            int j = 6;
            while (j < line_refresh.size()) {
              if (!((String)line_refresh.get(j)).equals("OL")) {
                allele = (String)line_refresh.get(j);
                if ((!allele.contentEquals("X")) && (!allele.contentEquals("Y"))) {
                  JOptionPane.showMessageDialog(null, "AMEL allele should be X or Y in the calibration file");
                  allOK = false;
                  return;
                }
                try
                {
                  height = Integer.parseInt((String)line_refresh.get(j + 2));
                } catch (NumberFormatException e) {
                  int height;
                  JOptionPane.showMessageDialog(null, "Height should be an integer in the calibration file");
                  allOK = false; return;
                }
                int height;
                CEESItAlgorithm.AMEL_Peak peakobject = new CEESItAlgorithm.AMEL_Peak(allele, height);
                loci_peaks.add(peakobject);
                loci_alleles.add(peakobject.getAllele());
              }
              j += 3;
            }
            
            for (String allele = loci_peaks.iterator(); allele.hasNext();) { peakobj1 = (CEESItAlgorithm.AMEL_Peak)allele.next();
              allele1 = peakobj1.getAllele();
              int count = Collections.frequency(loci_alleles, allele1);
              if (count > 1) {
                for (CEESItAlgorithm.AMEL_Peak peakobj2 : loci_peaks) {
                  String allele2 = peakobj2.getAllele();
                  if (allele1.contentEquals(allele2)) {
                    int index1 = loci_peaks.indexOf(peakobj1);
                    int index2 = loci_peaks.indexOf(peakobj2);
                    if (index1 != index2) {
                      int h1 = peakobj1.getHeight();
                      int h2 = peakobj2.getHeight();
                      if (h1 >= h2) {
                        if (!peakalleles_deleted.contains(allele2)) {
                          peaks_tobedeleted.add(peakobj2);
                          peakalleles_deleted.add(allele2);
                        }
                        
                      }
                      else if (!peakalleles_deleted.contains(allele1)) {
                        peaks_tobedeleted.add(peakobj1);
                        peakalleles_deleted.add(allele1);
                      }
                    }
                  }
                }
              }
            }
            CEESItAlgorithm.AMEL_Peak peakobj1;
            String allele1;
            for (CEESItAlgorithm.AMEL_Peak peakobj : loci_peaks) {
              if (!peaks_tobedeleted.contains(peakobj)) {
                loci_peaks_refresh.add(peakobj);
                loci_alleles_refresh.add(peakobj.getAllele());
              }
            }
            
            if (!trueallele1.contentEquals(trueallele2)) {
              for (String allele : trueAlleles) {
                if (loci_alleles_refresh.contains(allele)) {
                  for (CEESItAlgorithm.AMEL_Peak peakobj : loci_peaks_refresh) {
                    if (peakobj.getAllele().contentEquals(allele)) {
                      height = peakobj.getHeight();
                      ((ArrayList)((HashMap)trueValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(height));
                      ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                    }
                    
                  }
                } else {
                  ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                }
                
              }
              
            } else if (loci_alleles_refresh.contains("Y")) {
              for (CEESItAlgorithm.AMEL_Peak peakobj : loci_peaks_refresh) {
                if (peakobj.getAllele().contentEquals("Y")) {
                  int height = peakobj.getHeight();
                  ((ArrayList)((HashMap)noiseValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(height));
                  ((ArrayList)((HashMap)noiseDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                }
                
              }
            } else {
              ((ArrayList)((HashMap)noiseDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
            }
            
          }
        }
      }
      catch (IOException e)
      {
        System.out.println(e.getMessage());
      }
      
      for (e = masses.iterator(); e.hasNext();) { mass = ((Double)e.next()).doubleValue();
        for (String locus : calibLoci)
        {
          ArrayList<Integer> dovalues = (ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus);
          int do_count = Collections.frequency(dovalues, Integer.valueOf(0));
          double do_obs = dovalues.size();
          double final_do = do_count / do_obs;
          ((HashMap)dropoutCalibData.get(Double.valueOf(mass))).put(locus, Double.valueOf(final_do));
          
          DescriptiveStatistics trueStats = new DescriptiveStatistics();
          for (loci_alleles_refresh = ((ArrayList)((HashMap)trueValues.get(Double.valueOf(mass))).get(locus)).iterator(); loci_alleles_refresh.hasNext();) { int val = ((Integer)loci_alleles_refresh.next()).intValue();
            trueStats.addValue(val);
          }
          double trueMean = trueStats.getMean();
          double trueStddev = trueStats.getStandardDeviation();
          ((ArrayList)((HashMap)trueCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(trueMean));
          ((ArrayList)((HashMap)trueCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(trueStddev));
          
          ArrayList<Integer> noisedovalues = (ArrayList)((HashMap)noiseDO.get(Double.valueOf(mass))).get(locus);
          int noisedo_count = Collections.frequency(noisedovalues, Integer.valueOf(0));
          double noisedo_obs = noisedovalues.size();
          double final_noisedo = noisedo_count / noisedo_obs;
          ((HashMap)noiseDOCalibData.get(Double.valueOf(mass))).put(locus, Double.valueOf(final_noisedo));
          
          DescriptiveStatistics noiseStats = new DescriptiveStatistics();
          for (height = ((ArrayList)((HashMap)noiseValues.get(Double.valueOf(mass))).get(locus)).iterator(); height.hasNext();) { double val = ((Integer)height.next()).intValue();
            noiseStats.addValue(val);
          }
          double noiseMean = noiseStats.getMean();
          double noiseStddev = noiseStats.getStandardDeviation();
          ((ArrayList)((HashMap)noiseCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(noiseMean));
          ((ArrayList)((HashMap)noiseCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(noiseStddev));
          
          if (!locus.contentEquals("AMEL")) {
            ArrayList<Integer> rstutdovalues = (ArrayList)((HashMap)rstutterDO.get(Double.valueOf(mass))).get(locus);
            int rstutdo_count = Collections.frequency(rstutdovalues, Integer.valueOf(0));
            double rstut_obs = rstutdovalues.size();
            double rstut_do = rstutdo_count / rstut_obs;
            ((HashMap)rstutterDOCalibData.get(Double.valueOf(mass))).put(locus, Double.valueOf(rstut_do));
            
            ArrayList<Integer> fstutdovalues = (ArrayList)((HashMap)fstutterDO.get(Double.valueOf(mass))).get(locus);
            int fstutdo_count = Collections.frequency(fstutdovalues, Integer.valueOf(0));
            double fstut_obs = fstutdovalues.size();
            double fstut_do = fstutdo_count / fstut_obs;
            ((HashMap)fstutterDOCalibData.get(Double.valueOf(mass))).put(locus, Double.valueOf(fstut_do));
            
            DescriptiveStatistics rstutterStats = new DescriptiveStatistics();
            for (Iterator localIterator2 = ((ArrayList)((HashMap)rstutterValues.get(Double.valueOf(mass))).get(locus)).iterator(); localIterator2.hasNext();) { double val = ((Double)localIterator2.next()).doubleValue();
              rstutterStats.addValue(val);
            }
            double rstutterMean = rstutterStats.getMean();
            double rstutterStddev = rstutterStats.getStandardDeviation();
            ((ArrayList)((HashMap)rstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(rstutterMean));
            ((ArrayList)((HashMap)rstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(rstutterStddev));
            
            DescriptiveStatistics fstutterStats = new DescriptiveStatistics();
            for (Iterator localIterator3 = ((ArrayList)((HashMap)fstutterValues.get(Double.valueOf(mass))).get(locus)).iterator(); localIterator3.hasNext();) { double val = ((Double)localIterator3.next()).doubleValue();
              fstutterStats.addValue(val);
            }
            double fstutterMean = fstutterStats.getMean();
            double fstutterStddev = fstutterStats.getStandardDeviation();
            ((ArrayList)((HashMap)fstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(fstutterMean));
            ((ArrayList)((HashMap)fstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(fstutterStddev));
          }
        }
      }
      double mass; }
    
    public HashMap<Double, HashMap<String, Double>> getDOCalibData() { return dropoutCalibData; }
    
    public HashMap<Double, HashMap<String, Double>> getNoiseDOCalibData() {
      return noiseDOCalibData;
    }
    
    public HashMap<Double, HashMap<String, Double>> getfstutDOCalibData() { return fstutterDOCalibData; }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getfstutterCalibData() {
      return fstutterCalibData;
    }
    
    public HashSet<String> getLoci() { return calibLoci; }
    
    public HashSet<Double> getMasses() {
      return masses;
    }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getNoiseCalibData() { return noiseCalibData; }
    
    public HashMap<Double, HashMap<String, Double>> getrstutDOCalibData() {
      return rstutterDOCalibData;
    }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getrstutterCalibData() { return rstutterCalibData; }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getTrueCalibData() {
      return trueCalibData;
    }
    
    public boolean allOk() { return allOK; }
  }
  

  private static class parseSampleFile
  {
    private String sample_file_path;
    
    private HashMap<String, HashMap<CEESItAlgorithm.STR_Allele, CEESItAlgorithm.Peak>> loci_peaks;
    private HashMap<String, HashMap<String, CEESItAlgorithm.AMEL_Peak>> amel_peaks;
    private LinkedHashMap<String, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double>> loci_heightsdist;
    private ArrayList<String> sample_loci;
    private boolean allOK;
    
    parseSampleFile(String samplefilepath)
    {
      sample_file_path = samplefilepath;
      loci_peaks = new HashMap();
      sample_loci = new ArrayList();
      amel_peaks = new HashMap();
      loci_heightsdist = new LinkedHashMap();
      allOK = true;
      try
      {
        CEESItAlgorithm.OpenAndReadFile samplefile = new CEESItAlgorithm.OpenAndReadFile(sample_file_path);
        String[] samplefilelines = samplefile.FileContents();
        String locus; Object peaks_tobedeleted; String allele; for (int linecount = 1; linecount < samplefilelines.length; linecount++) {
          String line = samplefilelines[linecount];
          String[] line_parts = line.split(",");
          List<String> line_refresh = new ArrayList();
          for (String element : line_parts) {
            if ((element != null) && 
              (!element.contentEquals(" "))) {
              line_refresh.add(element);
            }
          }
          
          locus = (String)line_refresh.get(1);
          
          sample_loci.add(locus);
          double heights_sum;
          CEESItAlgorithm.Peak peakobj; double min_ratio; if (!locus.equals("AMEL")) {
            if (!CEESItAlgorithm.Freq_Table.containsKey(locus)) {
              JOptionPane.showMessageDialog(null, "Locus in the sample file not present in frequency file. ");
              allOK = false;
              return;
            }
            
            loci_heightsdist.put(locus, new LinkedHashMap());
            loci_peaks.put(locus, new HashMap());
            
            Object peakalleles_deleted = new ArrayList();
            Object peaks_tobedeleted = new ArrayList();
            ArrayList<CEESItAlgorithm.Peak> peak_array = new ArrayList();
            ArrayList<CEESItAlgorithm.STR_Allele> peak_alleles = new ArrayList();
            int i = 3;
            CEESItAlgorithm.Peak peakobject; while (i < line_refresh.size()) {
              if (!((String)line_refresh.get(i)).equals("OL"))
              {
                try {
                  a = Double.parseDouble((String)line_refresh.get(i));
                } catch (NumberFormatException e) {
                  double a;
                  JOptionPane.showMessageDialog(null, "Allele should be a real number in the sample file");
                  allOK = false;
                  return;
                }
                CEESItAlgorithm.STR_Allele allele = new CEESItAlgorithm.STR_Allele((String)line_refresh.get(i));
                try
                {
                  height = Integer.parseInt((String)line_refresh.get(i + 2));
                } catch (NumberFormatException e) {
                  int height;
                  allOK = false;
                  JOptionPane.showMessageDialog(null, "Height should be an integer in the sample file"); return;
                }
                
                int height;
                peakobject = new CEESItAlgorithm.Peak(allele, height);
                peak_array.add(peakobject);
                peak_alleles.add(peakobject.getAllele());
              }
              i += 3;
            }
            
            for (double a = peak_array.iterator(); a.hasNext();) { peakobj1 = (CEESItAlgorithm.Peak)a.next();
              allele1 = peakobj1.getAllele();
              int count = Collections.frequency(peak_alleles, allele1);
              if (count > 1) {
                for (CEESItAlgorithm.Peak peakobj2 : peak_array) {
                  CEESItAlgorithm.STR_Allele allele2 = peakobj2.getAllele();
                  if (allele1 == allele2) {
                    int index1 = peak_array.indexOf(peakobj1);
                    int index2 = peak_array.indexOf(peakobj2);
                    if (index1 != index2) {
                      int h1 = peakobj1.getHeight();
                      int h2 = peakobj2.getHeight();
                      if (h1 >= h2) {
                        if (!((ArrayList)peakalleles_deleted).contains(allele2)) {
                          ((ArrayList)peaks_tobedeleted).add(peakobj2);
                          ((ArrayList)peakalleles_deleted).add(allele2);
                        }
                        
                      }
                      else if (!((ArrayList)peakalleles_deleted).contains(allele1)) {
                        ((ArrayList)peaks_tobedeleted).add(peakobj1);
                        ((ArrayList)peakalleles_deleted).add(allele1);
                      }
                    }
                  }
                }
              }
            }
            CEESItAlgorithm.Peak peakobj1;
            CEESItAlgorithm.STR_Allele allele1;
            for (CEESItAlgorithm.Peak peakobj : peak_array) {
              if (!((ArrayList)peaks_tobedeleted).contains(peakobj)) {
                ((HashMap)loci_peaks.get(locus)).put(peakobj.getAllele(), peakobj);
              }
            }
            
            heights_sum = 0.0D;
            for (CEESItAlgorithm.STR_Allele allele : ((LinkedHashMap)CEESItAlgorithm.Freq_Table.get(locus)).keySet()) {
              if (((HashMap)loci_peaks.get(locus)).containsKey(allele)) {
                peakobj = (CEESItAlgorithm.Peak)((HashMap)loci_peaks.get(locus)).get(allele);
                int height = peakobj.getHeight();
                heights_sum += height;
              }
              else {
                heights_sum += CEESItAlgorithm.min_height;
              }
            }
            
            min_ratio = CEESItAlgorithm.min_height / heights_sum;
            min_ratio = Math.round(min_ratio * 10000.0D) / 10000.0D;
            
            for (CEESItAlgorithm.STR_Allele allele : ((LinkedHashMap)CEESItAlgorithm.Freq_Table.get(locus)).keySet()) {
              if (((HashMap)loci_peaks.get(locus)).containsKey(allele)) {
                CEESItAlgorithm.Peak peakobj = (CEESItAlgorithm.Peak)((HashMap)loci_peaks.get(locus)).get(allele);
                int height = peakobj.getHeight();
                double height_ratio = height / heights_sum;
                height_ratio = Math.round(height_ratio * 1000.0D) / 1000.0D;
                ((LinkedHashMap)loci_heightsdist.get(locus)).put(allele, Double.valueOf(height_ratio));
              }
              else {
                ((LinkedHashMap)loci_heightsdist.get(locus)).put(allele, Double.valueOf(min_ratio));
              }
            }
          }
          else {
            amel_peaks.put(locus, new HashMap());
            Object peakalleles_deleted = new ArrayList();
            peaks_tobedeleted = new ArrayList();
            ArrayList<CEESItAlgorithm.AMEL_Peak> peak_array = new ArrayList();
            ArrayList<String> peak_alleles = new ArrayList();
            
            int i = 3;
            while (i < line_refresh.size()) {
              if (!((String)line_refresh.get(i)).equals("OL")) {
                allele = (String)line_refresh.get(i);
                if ((!allele.contentEquals("X")) && (!allele.contentEquals("Y"))) {
                  JOptionPane.showMessageDialog(null, "AMEL Allele should be X or Y in the sample file");
                  allOK = false;
                  return;
                }
                try
                {
                  height = Integer.parseInt((String)line_refresh.get(i + 2));
                } catch (NumberFormatException e) {
                  int height;
                  allOK = false;
                  JOptionPane.showMessageDialog(null, "Height should be an integer in the sample file"); return;
                }
                int height;
                CEESItAlgorithm.AMEL_Peak peakobject = new CEESItAlgorithm.AMEL_Peak(allele, height);
                peak_array.add(peakobject);
                peak_alleles.add(peakobject.getAllele());
              }
              i += 3;
            }
            
            for (allele = peak_array.iterator(); allele.hasNext();) { peakobj1 = (CEESItAlgorithm.AMEL_Peak)allele.next();
              allele1 = peakobj1.getAllele();
              int count = Collections.frequency(peak_alleles, allele1);
              if (count > 1) {
                for (CEESItAlgorithm.AMEL_Peak peakobj2 : peak_array) {
                  String allele2 = peakobj2.getAllele();
                  if (allele1.contentEquals(allele2)) {
                    int index1 = peak_array.indexOf(peakobj1);
                    int index2 = peak_array.indexOf(peakobj2);
                    if (index1 != index2) {
                      int h1 = peakobj1.getHeight();
                      int h2 = peakobj2.getHeight();
                      if (h1 >= h2) {
                        if (!((ArrayList)peakalleles_deleted).contains(allele2)) {
                          ((ArrayList)peaks_tobedeleted).add(peakobj2);
                          ((ArrayList)peakalleles_deleted).add(allele2);
                        }
                        
                      }
                      else if (!((ArrayList)peakalleles_deleted).contains(allele1)) {
                        ((ArrayList)peaks_tobedeleted).add(peakobj1);
                        ((ArrayList)peakalleles_deleted).add(allele1);
                      }
                    }
                  }
                }
              }
            }
            CEESItAlgorithm.AMEL_Peak peakobj1;
            String allele1;
            for (CEESItAlgorithm.AMEL_Peak peakobj : peak_array) {
              if (!((ArrayList)peaks_tobedeleted).contains(peakobj)) {
                ((HashMap)amel_peaks.get(locus)).put(peakobj.getAllele(), peakobj);
              }
            }
          }
        }
      }
      catch (IOException e) {
        System.out.println(e.getMessage());
      }
    }
    
    public HashMap<String, HashMap<CEESItAlgorithm.STR_Allele, CEESItAlgorithm.Peak>> getLociPeaks() { return loci_peaks; }
    
    public ArrayList<String> getSampleLoci() {
      return sample_loci;
    }
    
    public HashMap<String, HashMap<String, CEESItAlgorithm.AMEL_Peak>> getAMELPeaks() { return amel_peaks; }
    
    public LinkedHashMap<String, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double>> getLociHeightsDist() {
      return loci_heightsdist;
    }
    
    public boolean allOk() { return allOK; }
  }
  
  private static class FreqTable
  {
    private String path;
    private ArrayList<String> loci_list;
    private LinkedHashMap<String, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double>> freq_table;
    private LinkedHashMap<String, ArrayList<CEESItAlgorithm.STR_Allele>> freq_alleles;
    private LinkedHashMap<String, HashSet<CEESItAlgorithm.STR_Allele>> allPossAlleles;
    private boolean allOK;
    private HashMap<String, Double> locusSum;
    
    FreqTable(String file_path)
    {
      path = file_path;
      loci_list = new ArrayList();
      freq_table = new LinkedHashMap();
      freq_alleles = new LinkedHashMap();
      allPossAlleles = new LinkedHashMap();
      locusSum = new HashMap();
      allOK = true;
      try
      {
        CEESItAlgorithm.OpenAndReadFile freqfile = new CEESItAlgorithm.OpenAndReadFile(path);
        String[] fileLines = freqfile.FileContents();
        for (int i = 1; i < fileLines.length; i++) {
          String line = fileLines[i];
          String[] parts = line.split(",");
          String locus = parts[0];
          if (!loci_list.contains(locus)) {
            loci_list.add(locus);
            locusSum.put(locus, Double.valueOf(0.0D));
          }
          try
          {
            frequency = Double.parseDouble(parts[2]);
          } catch (NumberFormatException e) {
            double frequency;
            JOptionPane.showMessageDialog(null, "Frequency should be a real number in the frequency file");
            allOK = false; return;
          }
          double frequency;
          locusSum.put(locus, Double.valueOf(((Double)locusSum.get(locus)).doubleValue() + frequency));
        }
        
        for (String locus : loci_list) {
          freq_table.put(locus, new LinkedHashMap());
          freq_alleles.put(locus, new ArrayList());
          allPossAlleles.put(locus, new HashSet());
        }
        
        for (int i = 1; i < fileLines.length; i++) {
          String line = fileLines[i];
          String[] parts = line.split(",");
          String locus = parts[0];
          try
          {
            a = Double.parseDouble(parts[1]);
          } catch (NumberFormatException e) {
            double a;
            JOptionPane.showMessageDialog(null, "Allele should be a real number in the frequency file");
            allOK = false; return;
          }
          
          double a;
          CEESItAlgorithm.STR_Allele allele = new CEESItAlgorithm.STR_Allele(parts[1]);
          
          try
          {
            frequency = Double.parseDouble(parts[2]);
          } catch (NumberFormatException e) {
            double frequency;
            JOptionPane.showMessageDialog(null, "Frequency should be a real number in the frequency file");
            allOK = false; return;
          }
          
          double frequency;
          CEESItAlgorithm.STR_Allele revAllele = new CEESItAlgorithm.STR_Allele(allele.getRStutAllele());
          CEESItAlgorithm.STR_Allele fowAllele = new CEESItAlgorithm.STR_Allele(allele.getFStutAllele());
          ((HashSet)allPossAlleles.get(locus)).add(allele);
          ((HashSet)allPossAlleles.get(locus)).add(revAllele);
          ((HashSet)allPossAlleles.get(locus)).add(fowAllele);
          
          if (CEESItAlgorithm.largestAllele < allele.getValue()) {
            CEESItAlgorithm.access$1402(allele.getValue());
          }
          
          double freqPrime = Math.round(frequency / ((Double)locusSum.get(locus)).doubleValue() * 10000.0D) / 10000.0D;
          
          ((LinkedHashMap)freq_table.get(locus)).put(allele, Double.valueOf(freqPrime));
          ((ArrayList)freq_alleles.get(locus)).add(allele);
        }
      }
      catch (IOException e)
      {
        System.out.println(e.getMessage());
      }
    }
    
    public ArrayList<String> getFreqLociList() { return loci_list; }
    
    public LinkedHashMap<String, LinkedHashMap<CEESItAlgorithm.STR_Allele, Double>> getFreqTable() {
      return freq_table;
    }
    
    public LinkedHashMap<String, ArrayList<CEESItAlgorithm.STR_Allele>> getFreqAlleles() { return freq_alleles; }
    
    public LinkedHashMap<String, HashSet<CEESItAlgorithm.STR_Allele>> getAllPossAlleles() {
      return allPossAlleles;
    }
    
    public boolean allOk() { return allOK; }
  }
  

  private static class POI_genotype_create
  {
    private String file_path;
    private HashMap<String, ArrayList<CEESItAlgorithm.STR_Allele>> poi_gen;
    private HashMap<String, ArrayList<String>> poi_gen_amel;
    private boolean allOK;
    
    POI_genotype_create(String filepath)
    {
      file_path = filepath;
      poi_gen = new HashMap();
      poi_gen_amel = new HashMap();
      allOK = true;
      try
      {
        CEESItAlgorithm.OpenAndReadFile freqfile = new CEESItAlgorithm.OpenAndReadFile(file_path);
        String[] fileLines = freqfile.FileContents();
        for (int i = 1; i < fileLines.length; i++) {
          String line = fileLines[i];
          String[] parts = line.split(",");
          String locus = parts[0];
          if ((!locus.contentEquals("AMEL")) && (!CEESItAlgorithm.Sample_Loci.contains(locus))) {
            JOptionPane.showMessageDialog(null, "Locus in the POI genotype file not present in sample file");
            allOK = false;
            return;
          }
          String allele1 = parts[1];
          String allele2 = parts[2];
          if (!locus.contentEquals("AMEL")) {
            poi_gen.put(locus, new ArrayList());
            try
            {
              Double.parseDouble(allele1);
            }
            catch (NumberFormatException e) {
              JOptionPane.showMessageDialog(null, "POI allele should be a real number in the POI genotype file");
              allOK = false;
              return;
            }
            try {
              Double.parseDouble(allele2);
            }
            catch (NumberFormatException e) {
              JOptionPane.showMessageDialog(null, "POI allele should be a real number in the POI genotype file");
              allOK = false;
              return;
            }
            
            CEESItAlgorithm.STR_Allele a1 = new CEESItAlgorithm.STR_Allele(allele1);
            CEESItAlgorithm.STR_Allele a2 = new CEESItAlgorithm.STR_Allele(allele2);
            if (a1.getValue() <= a2.getValue()) {
              ((ArrayList)poi_gen.get(locus)).add(a1);
              ((ArrayList)poi_gen.get(locus)).add(a2);
            }
            else {
              ((ArrayList)poi_gen.get(locus)).add(a2);
              ((ArrayList)poi_gen.get(locus)).add(a1);
            }
          }
          else {
            if ((!allele1.contentEquals("X")) && (!allele1.contentEquals("Y"))) {
              JOptionPane.showMessageDialog(null, "AMEL allele should be X or Y in the POI genotype file");
              allOK = false;
              return;
            }
            if ((!allele2.contentEquals("X")) && (!allele2.contentEquals("Y"))) {
              JOptionPane.showMessageDialog(null, "AMEL allele should be X or Y in the POI genotype file");
              allOK = false;
              return;
            }
            poi_gen_amel.put(locus, new ArrayList(Arrays.asList(new String[] { allele1, allele2 })));
          }
        }
      }
      catch (IOException e) {
        System.out.println(e.getMessage());
      }
    }
    
    public HashMap<String, ArrayList<CEESItAlgorithm.STR_Allele>> getPOIgen() { return poi_gen; }
    
    public HashMap<String, ArrayList<String>> getPOIAMELgen() {
      return poi_gen_amel;
    }
    
    public boolean allOK() { return allOK; }
  }
  

  private static class OpenAndReadFile
  {
    private final String path;
    
    OpenAndReadFile(String file_path) { path = file_path; }
    
    public String[] FileContents() throws IOException {
      FileReader fr = new FileReader(path);
      
      BufferedReader textReader = new BufferedReader(fr);Throwable localThrowable3 = null;
      try { int numberOfLines = readLines();
        String[] textData = new String[numberOfLines];
        
        for (int i = 0; i < numberOfLines; i++) {
          textData[i] = textReader.readLine();
        }
      }
      catch (Throwable localThrowable1)
      {
        localThrowable3 = localThrowable1;throw localThrowable1;


      }
      finally
      {

        if (textReader != null) if (localThrowable3 != null) try { textReader.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else textReader.close(); }
      String[] textData; return textData;
    }
    
    public int readLines() throws IOException { FileReader file_to_read = new FileReader(path);
      
      BufferedReader bf = new BufferedReader(file_to_read);Throwable localThrowable3 = null;
      try { int numberOfLines = 0;
        while (bf.readLine() != null) {
          numberOfLines++;
        }
      }
      catch (Throwable localThrowable1)
      {
        localThrowable3 = localThrowable1;throw localThrowable1;

      }
      finally
      {
        if (bf != null) if (localThrowable3 != null) try { bf.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else bf.close(); }
      int numberOfLines; return numberOfLines;
    }
  }
  


  public static void printCEESItResults()
  {
    try
    {
      FileWriter fstream = new FileWriter(Output_File_Name);
      BufferedWriter output_file = new BufferedWriter(fstream);Throwable localThrowable3 = null;
      try {
        output_file.write("Calibration File: " + calibrationPath + "\n");
        output_file.write("Frequency File: " + Freq_File + "\n");
        output_file.write("Sample File: " + Sample_File_Name + "\n");
        output_file.write("POI genotype File: " + poiGenFile + "\n\n");
        
        output_file.write("Sample DNA input: " + DNA_Mass + "ng\n");
        
        output_file.write("Population substructure correction factor (theta): " + theta + "\n");
        output_file.write("Number of simulated random genotypes: " + poiSamples + "\n");
        output_file.write("Number of contributors: " + noc + "\n\n");
        output_file.write("Time taken: " + time_taken + " minutes\n");
        
        for (String locus : Loci_not_in_calib_samples) {
          output_file.write("Locus " + locus + " was not included in the calculation because it is not present in the calibration samples\n");
        }
        for (String locus : Loci_not_in_freq_table) {
          output_file.write("Locus " + locus + " was not included in the calculation because it is not present in the frequency table\n");
        }
        for (String locus : Loci_no_true) {
          output_file.write("Locus " + locus + " was not included in the calculation because it had too few data points for allelic peaks\n");
        }
        for (String locus : Loci_no_noise) {
          output_file.write("Locus " + locus + " was not included in the calculation because it had too few data points for noise peaks\n");
        }
        for (String locus : Sample_Loci) {
          if ((!Loci_RStutter.contains(locus)) && 
            (!locus.contentEquals("AMEL"))) {
            output_file.write("Locus " + locus + " had too few data points for reverse stutter \n");
          }
        }
        
        for (String locus : Sample_Loci) {
          if ((!Loci_FStutter.contains(locus)) && 
            (!locus.contentEquals("AMEL"))) {
            output_file.write("Locus " + locus + " had too few data points for forward stutter \n");
          }
        }
        





        output_file.write("\n\n");
        
        if (truePoiProb.doubleValue() != Double.NEGATIVE_INFINITY)
        {
          output_file.write("Log(LR): " + trueLR + "\n");
          int numgreaterpoi;
          if (!inexactPValue) {
            numgreaterpoi = (int)numGensGreaterPOI;
            
            output_file.write("p-value: " + truePValue + "\n\n");
          }
          else
          {
            output_file.write("Upper bound for p-value: " + truePValue + "\n\n");
          }
          
          output_file.write("---------LR distribution--------- \n\n");
          
          output_file.write("Log(LR) bin: Frequency\n");
          
          for (Iterator localIterator2 = randPOIProbs.keySet().iterator(); localIterator2.hasNext();) { double prob = ((Double)localIterator2.next()).doubleValue();
            double lr = Math.round(prob - LRDen);
            double lower = lr - 0.5D;
            double upper = lr + 0.5D;
            int freq = ((Integer)randPOIProbs.get(Double.valueOf(prob))).intValue();
            output_file.write(lower + " to " + upper + " : " + freq + "\n");
          }
          
          output_file.close();
        }
        else
        {
          output_file.write("The LR numerator for the POI was 0.\n");
          output_file.write("A p-value was not computed.\n\n");
        }
      }
      catch (Throwable localThrowable5)
      {
        localThrowable3 = localThrowable5;throw localThrowable5;






































      }
      finally
      {






































        if (output_file != null) if (localThrowable3 != null) try { output_file.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else output_file.close();
      }
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }
  


  public void printInterruptedCEESItResults()
  {
    try
    {
      FileWriter fstream = new FileWriter(Output_File_Name);
      BufferedWriter output_file = new BufferedWriter(fstream);Throwable localThrowable3 = null;
      try { output_file.write("Calibration File: " + calibrationPath + "\n");
        output_file.write("Frequency File: " + Freq_File + "\n");
        output_file.write("Sample File: " + Sample_File_Name + "\n");
        output_file.write("Sample DNA input: " + DNA_Mass + "ng\n");
        output_file.write("\n\n");
        output_file.write("CEESIt was terminated by the user before completion.\n");
        output_file.close();
      }
      catch (Throwable localThrowable1)
      {
        localThrowable3 = localThrowable1;throw localThrowable1;


      }
      finally
      {


        if (output_file != null) if (localThrowable3 != null) try { output_file.close(); } catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2); } else output_file.close();
      }
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }
  

  private static class Peak
  {
    private final CEESItAlgorithm.STR_Allele allele;
    private final int height;
    
    Peak(CEESItAlgorithm.STR_Allele allele, int height)
    {
      this.allele = allele;
      this.height = height;
    }
    
    public CEESItAlgorithm.STR_Allele getAllele() { return allele; }
    
    public int getHeight() {
      return height;
    }
    
    public String toString() {
      return allele + "," + height;
    }
  }
  

  private static class AMEL_Peak
  {
    private final String allele;
    private final int height;
    
    AMEL_Peak(String assignallele, int assignheight)
    {
      allele = assignallele;
      height = assignheight;
    }
    
    public String getAllele() { return allele; }
    
    public int getHeight() {
      return height;
    }
    
    public String toString() {
      return allele + "," + height;
    }
  }
  
  private static class Callable_threadcalcPOIProbJob_object
  {
    private final double num_val;
    
    Callable_threadcalcPOIProbJob_object(double numval)
    {
      num_val = numval;
    }
    
    public double getNumValue() { return num_val; }
  }
  








  private static ArrayList<double[]> mixRatios = new ArrayList();
  
  private static HashMap<String, Integer> HeightsDist_Final_Values;
  
  private static double mrProb;
  
  private static LinkedHashMap<String, LinkedHashMap<STR_Allele, Double>> Freq_Table;
  private static LinkedHashMap<String, ArrayList<STR_Allele>> freqAlleles;
  private static HashMap<String, Integer> AlleleFreqDist_Final_Values;
  private static HashMap<Locus, Integer> genoFreqDistFinalValues;
  private static LinkedHashMap<Locus, LinkedHashMap<ArrayList<STR_Allele>, Double>> freqGenotypes;
  private static LinkedHashMap<Locus, LinkedHashMap<Integer, ArrayList<STR_Allele>>> genoFreqIntervals;
  private static LinkedHashMap<String, LinkedHashMap<Integer, STR_Allele>> Freq_Intervals;
  private static ArrayList<String> Sample_Loci;
  private static HashMap<String, HashMap<STR_Allele, Peak>> Loci_Peaks = new HashMap();
  
  private static LinkedHashMap<String, LinkedHashMap<STR_Allele, Double>> Loci_HeightsDist;
  
  private static LinkedHashMap<String, LinkedHashMap<Integer, STR_Allele>> Heights_Intervals;
  
  private static Double truePoiProb;
  private static Double trueLR;
  private static HashMap<String, ArrayList<STR_Allele>> True_POI_gen;
  private static HashMap<String, ArrayList<String>> True_POI_AMELgen;
  private static double truePValue;
  private static double LRDen;
  private static double probWorkGenotypes;
  private static HashMap<Locus, HashMap<ArrayList<STR_Allele>, ArrayList<Double>>> genoProbs = new HashMap();
  
  private static HashMap<Locus, ArrayList<ArrayList<STR_Allele>>> workGenotypes;
  
  private static int largestAllele;
  
  private static double offset;
  
  private static HashMap<Double, Integer> randPOIProbs;
  private static ArrayList<Locus> Working_Loci;
  private static double time_taken;
  private static double DNA_Mass;
  private static String Freq_File;
  private static int noc;
  private static int poiSamples;
  private static String calibrationPath;
  private static String poiGenFile;
  private static String Sample_File_Name;
  private static String Output_File_Name;
  private static HashSet<String> Loci_RStutter;
  private static HashSet<String> Loci_FStutter;
  private static HashSet<String> Loci_no_true;
  private static HashSet<String> Loci_no_noise;
  private static HashSet<String> Loci_not_in_calib_samples;
  private static HashSet<String> Loci_not_in_freq_table;
  private static HashMap<String, double[]> True_Mean_Slope = new HashMap();
  private static HashMap<String, double[]> True_Stddev_Slope = new HashMap();
  private static HashMap<String, double[]> Noise_Mean_Slope = new HashMap();
  private static HashMap<String, double[]> Noise_Stddev_Slope = new HashMap();
  private static HashMap<String, double[]> R_Stutter_Mean = new HashMap();
  private static HashMap<String, double[]> R_Stutter_Stddev = new HashMap();
  private static HashMap<String, double[]> R_Stut_DO = new HashMap();
  private static HashMap<String, double[]> F_Stutter_Mean = new HashMap();
  private static HashMap<String, double[]> F_Stutter_Stddev = new HashMap();
  private static HashMap<String, double[]> F_Stut_DO = new HashMap();
  private static HashMap<String, double[]> Locus_DO = new HashMap();
  private static HashMap<String, Double> Noise_DO = new HashMap();
  
  private static boolean AllOK;
  
  private static boolean calibOK;
  
  private static boolean freqOK;
  
  private static boolean sampleOK;
  
  private static boolean poiFileOK;
  
  private static LinkedHashMap<String, HashSet<STR_Allele>> AllPossibleAlleles;
  
  private static double theta;
  private static double twoPi;
  private static boolean inexactPValue;
  private static String[] Sexes;
  private static HashMap<String, String[]> Sexes_Genotype;
  private static HashMap<Locus, ArrayList<ArrayList<String>>> AMELworkGenotypes;
  private static HashMap<Locus, HashMap<ArrayList<String>, ArrayList<Double>>> AMELgenoProbs = new HashMap();
  private static HashMap<String, HashMap<String, AMEL_Peak>> AMEL_Peaks;
  private static double numGensGreaterPOI;
}
