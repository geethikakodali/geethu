package ceesit_v1;




public class CEESItMain
{
  public CEESItMain() {}
  


  public static void main(String[] args)
  {
    CEESItWindow ui = new CEESItWindow();
    
    CEESItInputs inputs = new CEESItInputs();
    
    CEESItControl control = new CEESItControl(ui, inputs);
  }
}
