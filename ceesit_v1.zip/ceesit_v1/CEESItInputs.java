package ceesit_v1;

import java.io.File;
import javax.swing.JOptionPane;











public class CEESItInputs
{
  private File calibrationFile = null;
  private File frequencyFile = null;
  private File sampleFile = null;
  private File outputFile = null;
  private File poiGenotypeFile = null;
  

  private int NumberOfContributors = 0;
  private double dnaMass = 0.0D;
  private int numPValueSamples = 0;
  private double theta = 0.0D;
  


  private String dnaMassError = "";
  private String NumberOfContributorsError = "";
  private String NumberOfSamplesError = "";
  private String thetaError = "";
  



  CEESItInputs() {}
  



  public boolean updateNumericFields(String mass, String NumberContributors, String NumSamples, String Theta)
  {
    boolean fieldsValid = true;
    try
    {
      dnaMass = Double.parseDouble(mass);
    } catch (IllegalArgumentException e) {
      dnaMassError = "Invalid DNA mass value.";
      fieldsValid = false;
    }
    try
    {
      NumberOfContributors = Integer.parseInt(NumberContributors);
    } catch (IllegalArgumentException e) {
      NumberOfContributorsError = "Invalid value for maximum number of contributors. ";
      fieldsValid = false;
    }
    try
    {
      numPValueSamples = Integer.parseInt(NumSamples);
    } catch (IllegalArgumentException e) {
      NumberOfSamplesError = "Invalid value for number of p value samples. ";
      fieldsValid = false;
    }
    try
    {
      theta = Double.parseDouble(Theta);
    } catch (IllegalArgumentException e) {
      thetaError = "Invalid value for theta. ";
      fieldsValid = false;
    }
    







    return fieldsValid;
  }
  





  public boolean allFieldsValid()
  {
    if (calibrationFile == null) {
      JOptionPane.showMessageDialog(null, "A calibration file was not provided");
      return false;
    }
    
    if (frequencyFile == null) {
      JOptionPane.showMessageDialog(null, "A frequency file was not provided");
      return false;
    }
    
    if (sampleFile == null) {
      JOptionPane.showMessageDialog(null, "A sample file was not provided");
      return false;
    }
    
    if (poiGenotypeFile == null) {
      JOptionPane.showMessageDialog(null, "A POI genotype file was not provided");
      return false;
    }
    
    if (dnaMass < 0.0D) {
      dnaMassError = "Invalid DNA mass value.";
      return false;
    }
    
    if ((NumberOfContributors < 1) || (NumberOfContributors > 3)) {
      NumberOfContributorsError = "Invalid value for maximum number of contributors.";
      return false;
    }
    
    if (numPValueSamples <= 0) {
      NumberOfSamplesError = "Invalid value for number of p-value samples";
      return false;
    }
    
    if (theta < 0.0D) {
      thetaError = "Invalid value for theta";
      return false;
    }
    






    return true;
  }
  


  public void setDnaMassError(String error)
  {
    dnaMassError = error;
  }
  
  public void setNumberOfContributorsError(String error) {
    NumberOfContributorsError = error;
  }
  
  public void setNumberOfSamplesError(String error) {
    NumberOfSamplesError = error;
  }
  



  public void setThetaError(String error)
  {
    thetaError = error;
  }
  
  public void setCalibrationFile(File calibrationFile) {
    this.calibrationFile = calibrationFile;
  }
  
  public void setFrequencyFile(File frequencyFile) {
    this.frequencyFile = frequencyFile;
  }
  
  public void setSampleFile(File sampleFile) {
    this.sampleFile = sampleFile;
  }
  
  public void setpoiGenotypeFile(File poiFile) {
    poiGenotypeFile = poiFile;
  }
  
  public void setOutputFile(File outputFile) {
    this.outputFile = outputFile;
  }
  
  public void setNumberOfContributors(int NumberOfContributors) {
    this.NumberOfContributors = NumberOfContributors;
  }
  
  public void setNumberOfSamples(int NumberOfSamples) {
    numPValueSamples = NumberOfSamples;
  }
  
  public void setDNAMass(double mass) {
    dnaMass = mass;
  }
  



  public void setTheta(double Theta)
  {
    theta = Theta;
  }
  
  public File getCalibrationFile() {
    return calibrationFile;
  }
  
  public File getFrequencyFile() {
    return frequencyFile;
  }
  
  public File getSampleFile() {
    return sampleFile;
  }
  
  public File getPOIFile() {
    return poiGenotypeFile;
  }
  
  public File getOutputFile() {
    return outputFile;
  }
  
  public int getNumberOfContributors() {
    return NumberOfContributors;
  }
  
  public double getDNAMass() {
    return dnaMass;
  }
  



  public double getTheta()
  {
    return theta;
  }
  
  public int getNumPValueSamples() {
    return numPValueSamples;
  }
  
  public String getDnaMassError() {
    return dnaMassError;
  }
  
  public String getNumberOfContributorsError() {
    return NumberOfContributorsError;
  }
  
  public String getNumberOfSamplesError() {
    return NumberOfSamplesError;
  }
  
  public String getThetaError() {
    return thetaError;
  }
}
