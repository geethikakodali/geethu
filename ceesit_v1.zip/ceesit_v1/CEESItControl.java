package ceesit_v1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MathException;
import org.apache.commons.math.optimization.OptimizationException;











public class CEESItControl
  implements ActionListener
{
  private CEESItWindow ui = null;
  private CEESItInputs inputs = null;
  private CEESItThread ceesitThread;
  private JProgressBar progressBar = null;
  private final JFileChooser fileChooser = new JFileChooser();
  private CEESItAlgorithm ceesitAlgorithm = null;
  private final FileNameExtensionFilter textFileFilter = new FileNameExtensionFilter("txt", new String[] { "txt" });
  private final FileNameExtensionFilter csvFileFilter = new FileNameExtensionFilter("csv", new String[] { "csv" });
  


  public CEESItControl(CEESItWindow ui, CEESItInputs inputs)
  {
    this.ui = ui;
    this.inputs = inputs;
    ceesitThread = new CEESItThread();
    ceesitAlgorithm = new CEESItAlgorithm();
    progressBar = ui.getProgressBar();
    ui.setVisible(true);
    ui.addActionListenerToAllButtons(this);
  }
  



  public void runMatchIt()
    throws InterruptedException, ExecutionException, FunctionEvaluationException, IOException, OptimizationException, MathException
  {
    progressBar.setIndeterminate(true);
    progressBar.setString("CEESIt is running");
    
    boolean stoppedBeforeCompletion = false;
    boolean filesNotOk = false;
    try
    {
      ceesitAlgorithm.runCEESIt(inputs.getSampleFile(), inputs.getFrequencyFile(), inputs.getPOIFile(), inputs.getOutputFile(), inputs.getCalibrationFile(), inputs.getNumberOfContributors(), inputs.getNumPValueSamples(), inputs.getDNAMass(), inputs.getTheta(), progressBar);
      if (CEESItAlgorithm.everythingOK()) {
        CEESItAlgorithm.printCEESItResults();
      }
      else {
        filesNotOk = true;
      }
    }
    catch (ExecutionException|IOException|FunctionEvaluationException|OptimizationException e) {
      System.out.println(e.getMessage());
    }
    catch (InterruptedException ex) {
      stoppedBeforeCompletion = true;
      ceesitAlgorithm.printInterruptedCEESItResults();
    }
    
    ceesitThread = new CEESItThread();
    
    if (filesNotOk) {
      JOptionPane.showMessageDialog(ui, "The program could not start");
    }
    else if (stoppedBeforeCompletion) {
      JOptionPane.showMessageDialog(ui, "The program was stopped before completing computation");
    }
    else {
      JOptionPane.showMessageDialog(ui, "The program has finished running");
    }
    
    ui.setStartButtonEnabled(Boolean.TRUE);
    progressBar.setString("");
    progressBar.setIndeterminate(false);
  }
  






  public void actionPerformed(ActionEvent e)
  {
    switch (e.getActionCommand()) {
    case "frequency": 
      File file = getFile("Select Frequency File", csvFileFilter);
      if (file != null) {
        ui.setFrequencyFileSelectionText(file.getName());
        inputs.setFrequencyFile(file);
      }
      
      break;
    case "calibration": 
      File file = getFile("Select Calibration File", csvFileFilter);
      if (file != null) {
        ui.setCalibrationFileSelectionText(file.getName());
        inputs.setCalibrationFile(file);
      }
      
      break;
    case "sample": 
      File file = getFile("Select Sample File", csvFileFilter);
      if (file != null) {
        ui.setSampleFileSelectionText(file.getName());
        inputs.setSampleFile(file);
      }
      
      break;
    case "poiGenotype": 
      File file = getFile("Select POI genotype File", csvFileFilter);
      if (file != null) {
        ui.setpoiGenotypeFileSelectionText(file.getName());
        inputs.setpoiGenotypeFile(file);
      }
      
      break;
    case "output": 
      File file = makeFile("Select/Create Output File", textFileFilter);
      if (file != null) {
        ui.setOutputFileSelectionText(file.getName());
        inputs.setOutputFile(file);
      }
      
      break;
    case "start": 
      boolean start = true;
      


      if ((inputs.getOutputFile() != null) && (inputs.getOutputFile().exists()) && (inputs.getOutputFile().length() != 0L)) {
        int paneReturn = JOptionPane.showConfirmDialog(ui, "The file " + inputs.getOutputFile().getName() + " contains CEESIt program output. Do you want to overwrite it?", "Overwrite file?", 0);
        if (paneReturn != 0)
        {

          start = false;
        }
      }
      

      if ((start == true) && (inputs.updateNumericFields(ui.getDNAMassSelectionText(), ui.getNoContibutorsText(), ui.getNumberSamplesText(), ui.getThetaText())) && (inputs.allFieldsValid()))
      {

        if (inputs.getOutputFile() == null) {
          inputs.setOutputFile(new File(getAbsoluteFilePathWithoutExtension(inputs.getSampleFile()) + "_CEESIt_output.txt"));
          ui.setOutputFileSelectionText(inputs.getOutputFile().getName());
        }
        ceesitThread.start();
        ui.setStartButtonEnabled(Boolean.FALSE);
      }
      displayNumericFieldErrors();
      break;
    default: 
      ceesitThread.interrupt();
      progressBar.setString("");
      progressBar.setIndeterminate(false);
    }
    
  }
  




  private File getFile(String message, FileNameExtensionFilter filter)
  {
    fileChooser.setDialogTitle(message);
    fileChooser.setFileFilter(filter);
    int chooserReturn = fileChooser.showOpenDialog(ui);
    File selectedFile = null;
    
    if (chooserReturn == 0) {
      selectedFile = fileChooser.getSelectedFile();
    }
    return selectedFile;
  }
  




  private File makeFile(String message, FileNameExtensionFilter filter)
  {
    fileChooser.setFileFilter(filter);
    fileChooser.setDialogTitle(message);
    int chooserReturn = fileChooser.showSaveDialog(ui);
    File createdFile = null;
    
    if (chooserReturn == 0) {
      createdFile = fileChooser.getSelectedFile();
      


      if (createdFile.exists()) {
        int paneReturn = JOptionPane.showConfirmDialog(ui, "The file \"" + createdFile.getName() + "\" exists and will be overwritten by the output of the program. Do you want to continue?", "Overwrite file?", 0);
        if (paneReturn == 0) {
          createdFile.delete();
          try {
            createdFile.createNewFile();
          } catch (IOException e) {
            System.out.println(e.getMessage());
          }
        } else {
          createdFile = null;
        }
      } else {
        String pathName = createdFile.getAbsolutePath();
        int begin = pathName.length() - 4;
        
        if (!createdFile.getAbsolutePath().substring(begin).equals(".txt")) {
          createdFile = new File(createdFile.getAbsolutePath().concat(".txt"));
        }
        try {
          createdFile.createNewFile();
        } catch (IOException e) {
          System.out.println(e.getMessage());
        }
      }
    }
    
    return createdFile;
  }
  



  private String getAbsoluteFilePathWithoutExtension(File file)
  {
    int end = file.getAbsolutePath().length() - 4;
    return inputs.getSampleFile().getAbsolutePath().substring(0, end);
  }
  





  private void displayNumericFieldErrors()
  {
    String dnaMassError = inputs.getDnaMassError();
    String NumberOfContributorsError = inputs.getNumberOfContributorsError();
    String NumberOfSamplesError = inputs.getNumberOfSamplesError();
    String thetaError = inputs.getThetaError();
    

    if (!dnaMassError.equals("")) {
      JOptionPane.showMessageDialog(ui, "Input for \"DNA mass\" is not valid");
    }
    if (!NumberOfContributorsError.equals("")) {
      JOptionPane.showMessageDialog(ui, "Input for \"number of contributors\" is not valid");
    }
    if (!NumberOfSamplesError.equals("")) {
      JOptionPane.showMessageDialog(ui, "Input for \"number of p-value samples\" is not valid");
    }
    if (!thetaError.equals("")) {
      JOptionPane.showMessageDialog(ui, "Input for \"theta\" is not valid");
    }
    



    inputs.setDnaMassError("");
    inputs.setNumberOfContributorsError("");
    inputs.setNumberOfSamplesError("");
    
    inputs.setThetaError("");
  }
  
  class CEESItThread
    extends Thread
  {
    CEESItThread() {}
    
    public void run()
    {
      try
      {
        runMatchIt();
      } catch (InterruptedException ex) {
        Logger.getLogger(CEESItControl.class.getName()).log(Level.SEVERE, null, ex);
      } catch (ExecutionException ex) {
        Logger.getLogger(CEESItControl.class.getName()).log(Level.SEVERE, null, ex);
      } catch (FunctionEvaluationException ex) {
        Logger.getLogger(CEESItControl.class.getName()).log(Level.SEVERE, null, ex);
      } catch (IOException ex) {
        Logger.getLogger(CEESItControl.class.getName()).log(Level.SEVERE, null, ex);
      } catch (OptimizationException ex) {
        Logger.getLogger(CEESItControl.class.getName()).log(Level.SEVERE, null, ex);
      } catch (MathException ex) {
        Logger.getLogger(CEESItControl.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
  }
}
